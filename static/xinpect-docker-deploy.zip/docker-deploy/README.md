# 煋鉴 Xinpect - Docker 一键部署包

## 快速开始

```bash
# 1. 进入项目目录
cd xinpect-website

# 2. 复制并编辑环境变量
cp docker-deploy/.env.example docker-deploy/.env
vi docker-deploy/.env   # 修改关键配置

# 3. 一键启动
docker compose -f docker-deploy/docker-compose.yml up -d --build
```

启动后访问 `https://你的域名` 即可。

## 关键配置说明

### 必须修改

| 变量 | 说明 |
|------|------|
| `FLASK_SECRET_KEY` | 换为随机字符串 |
| `SMTP_*` | 邮件服务配置 |
| `GITHUB_CLIENT_*` | GitHub OAuth 配置 |
| `APP_DOMAIN` | 你的域名 |

### 内部服务地址

- Docker 部署时，宿主机服务用 `host.docker.internal`
- 原生部署时，用 `127.0.0.1`

## 生产环境

### SSL 证书

自动挂载 `/etc/letsencrypt` 目录。如果没有证书，会自动生成自签名证书（浏览器会提示不安全）。

生成 Let's Encrypt 证书：
```bash
sudo certbot certonly --standalone -d your-domain.com
```

### 停止现有 nginx

如果宿主机已有 nginx 占用 80/443，需先停止：
```bash
sudo systemctl stop nginx
sudo systemctl disable nginx
```

### 更新部署

```bash
# 拉取最新代码后
docker compose -f docker-deploy/docker-compose.yml up -d --build
```

## 日常运维

```bash
# 查看状态
docker compose -f docker-deploy/docker-compose.yml ps

# 查看日志
docker compose -f docker-deploy/docker-compose.yml logs -f xinpect

# 重启服务
docker compose -f docker-deploy/docker-compose.yml restart

# 停止服务
docker compose -f docker-deploy/docker-compose.yml down

# 备份数据
docker run --rm -v xinpect_data:/data -v $(pwd):/backup alpine \
  tar czf /backup/xinpect-backup-$(date +%Y%m%d).tar.gz /data
```

## 架构说明

容器内运行：
- **nginx** (80/443) — 反向代理 + SSL + 静态资源
- **gunicorn** (8621) — Flask 应用服务器

容器通过 `host.docker.internal` 访问宿主机上的内部服务（门房、扫描器、SkillPay）。

数据持久化在 `xinpect_data` Docker 卷中，包括 SQLite 数据库、报告、日志和上传文件。

## 端口说明

| 端口 | 服务 | 说明 |
|------|------|------|
| 80 | nginx | HTTP（自动跳转 HTTPS） |
| 443 | nginx | HTTPS |
| 8621 | gunicorn | Flask 应用（仅容器内） |

## 资源限制

默认限制 2 CPU / 2GB 内存，可在 `docker-compose.yml` 中调整。
