// ============================================================
// 煋鉴 Xinpect - 主 JavaScript 文件
// 原生 JS，不依赖任何框架
// ============================================================

(function() {
    'use strict';

    // ---------- 通用工具函数 ----------
    function $(selector, context) {
        return (context || document).querySelector(selector);
    }

    function $$(selector, context) {
        return Array.from((context || document).querySelectorAll(selector));
    }

    function formatFileSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // 千分位分隔符
    function formatNumber(num) {
        if (num === null || num === undefined || isNaN(num)) return '0';
        return Number(num).toLocaleString('en-US');
    }

    // ---------- 通用弹窗 (积分系统 v1.5) ----------
    function showCreditConfirmModal(options) {
        // options: { cost, totalLines, onConfirm, onCancel }
        var cost = options.cost || 0;
        var totalLines = options.totalLines || 0;
        var html = '<div class="credit-modal-overlay" id="credit-confirm-modal">' +
            '<div class="credit-modal">' +
                '<div class="credit-modal-header">' +
                    '<div class="credit-modal-icon">⚡</div>' +
                    '<div class="credit-modal-title">确认开始扫描</div>' +
                    '<div class="credit-modal-desc">扫描需要消耗积分，请确认后继续</div>' +
                '</div>' +
                '<div class="credit-modal-cost">' +
                    '<div class="cost-value">' + formatNumber(cost) + '<span class="cost-unit">积分</span></div>' +
                    '<div class="cost-detail">约 ' + formatNumber(totalLines) + ' 行代码</div>' +
                '</div>' +
                '<div class="credit-modal-hint">积分按代码行数计算，包含起步费10积分 + 按行计费</div>' +
                '<div class="credit-modal-actions">' +
                    '<button class="btn btn-secondary" id="confirm-cancel-btn">取消</button>' +
                    '<button class="btn btn-orange" id="confirm-ok-btn">确认扫描</button>' +
                '</div>' +
            '</div>' +
        '</div>';
        document.body.insertAdjacentHTML('beforeend', html);

        var modal = document.getElementById('credit-confirm-modal');
        document.getElementById('confirm-cancel-btn').addEventListener('click', function() {
            modal.remove();
            if (options.onCancel) options.onCancel();
        });
        document.getElementById('confirm-ok-btn').addEventListener('click', function() {
            modal.remove();
            if (options.onConfirm) options.onConfirm();
        });
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.remove();
                if (options.onCancel) options.onCancel();
            }
        });
    }

    function showCreditInsufficientModal(options) {
        // options: { currentCredits, needCredits, onBuyPack, onUpgrade }
        var current = options.currentCredits || 0;
        var need = options.needCredits || 0;
        var html = '<div class="credit-modal-overlay" id="credit-insufficient-modal">' +
            '<div class="credit-modal credit-insufficient">' +
                '<div class="credit-modal-header">' +
                    '<div class="credit-modal-icon">⚠️</div>' +
                    '<div class="credit-modal-title">积分不足</div>' +
                    '<div class="credit-modal-desc">当前积分不足以完成本次扫描</div>' +
                '</div>' +
                '<div class="credit-modal-cost">' +
                    '<div class="credit-compare-row">' +
                        '<span class="label">当前积分</span>' +
                        '<span class="value current">' + formatNumber(current) + '</span>' +
                    '</div>' +
                    '<div class="credit-compare-row">' +
                        '<span class="label">本次需要</span>' +
                        '<span class="value need">' + formatNumber(need) + '</span>' +
                    '</div>' +
                '</div>' +
                '<div class="credit-modal-actions">' +
                    '<button class="btn btn-secondary" id="insufficient-upgrade-btn">升级会员</button>' +
                    '<button class="btn btn-orange" id="insufficient-pack-btn">购买积分包</button>' +
                '</div>' +
            '</div>' +
        '</div>';
        document.body.insertAdjacentHTML('beforeend', html);

        var modal = document.getElementById('credit-insufficient-modal');
        document.getElementById('insufficient-upgrade-btn').addEventListener('click', function() {
            modal.remove();
            if (options.onUpgrade) options.onUpgrade();
        });
        document.getElementById('insufficient-pack-btn').addEventListener('click', function() {
            modal.remove();
            if (options.onBuyPack) options.onBuyPack();
        });
        modal.addEventListener('click', function(e) {
            if (e.target === modal) modal.remove();
        });
    }

    // 暴露积分相关全局函数
    window.XinpectCredit = {
        formatNumber: formatNumber,
        showCreditConfirmModal: showCreditConfirmModal,
        showCreditInsufficientModal: showCreditInsufficientModal
    };

    // ---------- 导航栏交互 ----------
    function initNavbar() {
        // 滚动时添加阴影
        var navbar = $('.navbar');
        if (!navbar) return;

        window.addEventListener('scroll', function() {
            if (window.scrollY > 10) {
                navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.3)';
            } else {
                navbar.style.boxShadow = 'none';
            }
        });
    }

    // ---------- 上传功能 ----------
    var uploadState = {
        files: [],     // File 对象数组
        codeText: '',  // 粘贴的代码
        mode: 'file'   // file | code
    };

    function initUpload() {
        var uploadArea = $('#upload-area');
        if (!uploadArea) return;

        var fileInput = $('#file-input');
        var fileList = $('#file-list');
        var codeTab = $('#tab-code');
        var fileTab = $('#tab-file');
        var fileContent = $('#tab-content-file');
        var codeContent = $('#tab-content-code');
        var codeTextarea = $('#code-textarea');
        var fileNameInput = $('#code-filename');
        var scanBtn = $('#scan-btn');

        // Tab 切换
        if (fileTab && codeTab) {
            fileTab.addEventListener('click', function() {
                uploadState.mode = 'file';
                fileTab.classList.add('active');
                codeTab.classList.remove('active');
                fileContent.classList.add('active');
                codeContent.classList.remove('active');
                updateScanButton();
            });

            codeTab.addEventListener('click', function() {
                uploadState.mode = 'code';
                codeTab.classList.add('active');
                fileTab.classList.remove('active');
                codeContent.classList.add('active');
                fileContent.classList.remove('active');
                updateScanButton();
            });
        }

        // 点击上传区域触发文件选择
        uploadArea.addEventListener('click', function(e) {
            if (uploadState.mode === 'file' && e.target.closest('.file-list') === null) {
                fileInput && fileInput.click();
            }
        });

        // 文件选择
        if (fileInput) {
            fileInput.addEventListener('change', function(e) {
                handleFiles(e.target.files);
                // 重置 input 以便能重复选择相同文件
                fileInput.value = '';
            });
        }

        // 拖拽上传
        ['dragenter', 'dragover'].forEach(function(eventName) {
            uploadArea.addEventListener(eventName, function(e) {
                e.preventDefault();
                e.stopPropagation();
                uploadArea.classList.add('dragover');
            });
        });

        ['dragleave', 'drop'].forEach(function(eventName) {
            uploadArea.addEventListener(eventName, function(e) {
                e.preventDefault();
                e.stopPropagation();
                uploadArea.classList.remove('dragover');
            });
        });

        uploadArea.addEventListener('drop', function(e) {
            if (uploadState.mode === 'file' && e.dataTransfer.files.length > 0) {
                handleFiles(e.dataTransfer.files);
            }
        });

        // 代码粘贴
        if (codeTextarea) {
            codeTextarea.addEventListener('input', function() {
                uploadState.codeText = codeTextarea.value;
                updateScanButton();
            });
        }

        // 开始检测
        if (scanBtn) {
            scanBtn.addEventListener('click', startScan);
        }

        function handleFiles(fileListObj) {
            var maxSize = 5 * 1024 * 1024; // 单文件 5MB
            var totalMax = 20 * 1024 * 1024; // 批量 20MB
            var totalSize = uploadState.files.reduce(function(sum, f) { return sum + f.size; }, 0);

            for (var i = 0; i < fileListObj.length; i++) {
                var file = fileListObj[i];
                if (file.size > maxSize) {
                    showFlash('文件 "' + file.name + '" 超过 5MB 限制', 'error');
                    continue;
                }
                if (totalSize + file.size > totalMax) {
                    showFlash('上传文件总大小超过 20MB 限制', 'error');
                    break;
                }
                uploadState.files.push(file);
                totalSize += file.size;
            }

            renderFileList();
            updateScanButton();
        }

        function renderFileList() {
            if (!fileList) return;

            if (uploadState.files.length === 0) {
                fileList.innerHTML = '';
                return;
            }

            var html = '';
            uploadState.files.forEach(function(file, index) {
                html += '<div class="file-item">' +
                    '<div class="file-item-name">' +
                    '<span>📄</span>' +
                    '<span>' + escapeHtml(file.name) + '</span>' +
                    '</div>' +
                    '<span class="file-item-size">' + formatFileSize(file.size) + '</span>' +
                    '<button class="file-item-remove" data-index="' + index + '" title="移除">✕</button>' +
                    '</div>';
            });
            fileList.innerHTML = html;

            // 绑定移除事件
            $$('.file-item-remove', fileList).forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    var idx = parseInt(btn.getAttribute('data-index'));
                    uploadState.files.splice(idx, 1);
                    renderFileList();
                    updateScanButton();
                });
            });
        }

        function updateScanButton() {
            if (!scanBtn) return;
            var canScan = false;
            if (uploadState.mode === 'file') {
                canScan = uploadState.files.length > 0;
            } else {
                canScan = uploadState.codeText.trim().length > 0;
            }
            scanBtn.disabled = !canScan;
        }

        function startScan() {
            if (scanBtn.disabled) return;

            scanBtn.disabled = true;
            scanBtn.textContent = '检测中...';

            var formData = new FormData();
            formData.append('language', $('#language-select') ? $('#language-select').value : 'auto');

            if (uploadState.mode === 'file') {
                uploadState.files.forEach(function(file) {
                    formData.append('files', file, file.name);
                });
            } else {
                formData.append('code', uploadState.codeText);
                formData.append('filename', fileNameInput ? fileNameInput.value || 'code.txt' : 'code.txt');
            }

            // 显示进度
            var progressSection = $('#scan-progress');
            var uploadSection = $('#upload-form');
            if (progressSection && uploadSection) {
                uploadSection.style.display = 'none';
                progressSection.style.display = 'block';
            }

            var progressBar = $('.progress-bar-fill');
            var progressText = $('#progress-text');
            var progress = 0;
            var progressInterval = setInterval(function() {
                progress += Math.random() * 15;
                if (progress > 85) progress = 85;
                if (progressBar) progressBar.style.width = progress + '%';
            }, 500);

            fetch('/scan', {
                method: 'POST',
                body: formData
            }).then(function(response) {
                return response.json().then(function(data) {
                    if (!response.ok) throw new Error(data.error || '检测失败');
                    return data;
                });
            }).then(function(data) {
                clearInterval(progressInterval);
                if (progressBar) progressBar.style.width = '100%';
                if (progressText) progressText.textContent = '检测完成，正在跳转...';
                setTimeout(function() {
                    window.location.href = '/report/' + data.scan_id;
                }, 500);
            }).catch(function(error) {
                clearInterval(progressInterval);
                scanBtn.disabled = false;
                scanBtn.textContent = '开始检测';
                if (progressSection && uploadSection) {
                    progressSection.style.display = 'none';
                    uploadSection.style.display = 'block';
                }
                showFlash(error.message || '检测失败，请重试', 'error');
            });
        }
    }

    // ---------- 报告页交互 ----------
    function initReport() {
        // 维度卡片点击筛选
        $$('.dimension-card:not(.locked)').forEach(function(card) {
            card.addEventListener('click', function() {
                var brainId = card.getAttribute('data-brain');
                filterByBrain(brainId);
            });
        });

        // 严重程度筛选
        $$('.filter-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var severity = btn.getAttribute('data-filter');
                filterBySeverity(severity);
            });
        });

        // 问题展开/折叠
        $$('.issue-item .issue-header').forEach(function(header) {
            header.addEventListener('click', function() {
                var item = header.parentElement;
                item.classList.toggle('expanded');
            });
        });

        // 得分动画
        var scoreFill = $('.report-score-circle .score-fill');
        var scoreNumber = $('.report-score-number');
        if (scoreFill && scoreNumber) {
            var score = parseFloat(scoreNumber.textContent);
            var circumference = 2 * Math.PI * 60; // r=60
            var offset = circumference - (score / 100) * circumference;

            // 延迟执行动画
            setTimeout(function() {
                scoreFill.style.strokeDashoffset = offset;
            }, 200);
        }

        function filterByBrain(brainId) {
            $$('.dimension-card').forEach(function(card) {
                card.classList.remove('active');
            });
            var activeCard = document.querySelector('.dimension-card[data-brain="' + brainId + '"]');
            if (activeCard) activeCard.classList.add('active');

            $$('.issue-item').forEach(function(item) {
                var itemBrain = item.getAttribute('data-brain');
                if (brainId === 'all' || itemBrain === brainId) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });

            // 更新可见问题数
            updateVisibleIssuesCount();
        }

        function filterBySeverity(severity) {
            $$('.filter-btn').forEach(function(btn) {
                btn.classList.remove('active');
            });
            var activeBtn = document.querySelector('.filter-btn[data-filter="' + severity + '"]');
            if (activeBtn) activeBtn.classList.add('active');

            $$('.issue-item').forEach(function(item) {
                var itemSeverity = item.getAttribute('data-severity');
                if (severity === 'all' || itemSeverity === severity) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });

            updateVisibleIssuesCount();
        }

        function updateVisibleIssuesCount() {
            var count = $$('.issue-item').filter(function(item) {
                return item.style.display !== 'none';
            }).length;
            var countEl = $('#issues-count');
            if (countEl) {
                countEl.textContent = count;
            }
        }

        // 下载报告
        var downloadBtn = $('#download-report');
        if (downloadBtn) {
            downloadBtn.addEventListener('click', function() {
                var scanId = downloadBtn.getAttribute('data-scan-id');
                window.location.href = '/report/' + scanId + '/download';
            });
        }
    }

    // ---------- 充值页面 ----------
    function initRecharge() {
        $$('.recharge-plan').forEach(function(plan) {
            plan.addEventListener('click', function() {
                $$('.recharge-plan').forEach(function(p) { p.classList.remove('selected'); });
                plan.classList.add('selected');

                var planId = plan.getAttribute('data-plan');
                var payBtn = $('#pay-btn');
                if (payBtn) {
                    payBtn.disabled = false;
                    payBtn.setAttribute('data-plan', planId);
                }
            });
        });

        var payBtn = $('#pay-btn');
        if (payBtn) {
            payBtn.addEventListener('click', function() {
                var planId = payBtn.getAttribute('data-plan');
                if (!planId) return;

                // 调用创建订单接口
                fetch('/api/pay/create', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ plan_id: planId })
                }).then(function(response) {
                    return response.json();
                }).then(function(data) {
                    if (data.success) {
                        showPaymentModal(data.order_id, data.qr_url, data.amount);
                    } else {
                        showFlash(data.error || '创建订单失败', 'error');
                    }
                }).catch(function() {
                    showFlash('创建订单失败，请重试', 'error');
                });
            });
        }

        function showPaymentModal(orderId, qrUrl, amount) {
            var modalHtml = '<div id="pay-modal" style="position:fixed;inset:0;background:rgba(0,0,0,0.7);display:flex;align-items:center;justify-content:center;z-index:1000;">' +
                '<div class="payment-modal">' +
                '<h3 style="font-size:18px;margin-bottom:8px;">扫码支付</h3>' +
                '<p style="color:var(--text-secondary);font-size:14px;margin-bottom:16px;">支付金额：<strong style="color:var(--accent-orange);font-size:24px;">¥' + amount + '</strong></p>' +
                '<div class="qr-code">' +
                (qrUrl ? '<img src="' + qrUrl + '" alt="支付二维码" style="width:100%;height:100%;">' : '二维码生成中...') +
                '</div>' +
                '<p style="font-size:13px;color:var(--text-muted);margin-top:12px;">请使用微信扫码支付</p>' +
                '<p id="pay-status" style="font-size:13px;color:var(--warning);margin-top:8px;">等待支付中...</p>' +
                '<button class="btn btn-ghost btn-block" style="margin-top:16px;" onclick="this.closest(\'#pay-modal\').remove()">关闭</button>' +
                '</div></div>';

            document.body.insertAdjacentHTML('beforeend', modalHtml);

            // 轮询支付状态
            var statusEl = document.getElementById('pay-status');
            var pollCount = 0;
            var maxPolls = 60; // 最多轮询5分钟

            var pollInterval = setInterval(function() {
                pollCount++;
                if (pollCount > maxPolls) {
                    clearInterval(pollInterval);
                    if (statusEl) {
                        statusEl.textContent = '支付超时，请重新发起';
                        statusEl.style.color = 'var(--danger)';
                    }
                    return;
                }

                fetch('/api/pay/status/' + orderId)
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.status === 'paid') {
                            clearInterval(pollInterval);
                            if (statusEl) {
                                statusEl.textContent = '✓ 支付成功！即将刷新...';
                                statusEl.style.color = 'var(--success)';
                            }
                            setTimeout(function() {
                                window.location.reload();
                            }, 1500);
                        } else if (data.status === 'expired') {
                            clearInterval(pollInterval);
                            if (statusEl) {
                                statusEl.textContent = '订单已过期';
                                statusEl.style.color = 'var(--danger)';
                            }
                        }
                    }).catch(function() {});
            }, 5000);
        }
    }

    // ---------- Flash 消息 ----------
    function showFlash(message, type) {
        type = type || 'info';
        var container = $('#flash-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'flash-container';
            container.style.cssText = 'position:fixed;top:80px;left:50%;transform:translateX(-50%);z-index:200;min-width:280px;';
            document.body.appendChild(container);
        }

        var msg = document.createElement('div');
        msg.className = 'flash-message ' + type;
        msg.textContent = message;
        msg.style.boxShadow = '0 4px 12px rgba(0,0,0,0.3)';
        container.appendChild(msg);

        setTimeout(function() {
            msg.style.opacity = '0';
            msg.style.transform = 'translateY(-10px)';
            msg.style.transition = 'all 0.3s ease';
            setTimeout(function() { msg.remove(); }, 300);
        }, 3000);
    }

    // 暴露全局函数
    window.Xinpect = {
        showFlash: showFlash
    };

    // ---------- 复制 AI 修复代码 ----------
    function copyFixCode(btn) {
        var fixBlock = btn.closest('.ai-fix-block');
        if (!fixBlock) return;

        var fixContent = fixBlock.querySelector('.ai-fix-content');
        if (!fixContent) return;

        // 提取代码块内容
        var codeBlock = fixContent.querySelector('pre');
        var text = codeBlock ? codeBlock.textContent : fixContent.textContent;

        navigator.clipboard.writeText(text).then(function() {
            var originalText = btn.textContent;
            btn.textContent = '✅ 已复制';
            btn.style.background = 'var(--success)';
            btn.style.borderColor = 'var(--success)';
            btn.style.color = '#fff';
            setTimeout(function() {
                btn.textContent = originalText;
                btn.style.background = '';
                btn.style.borderColor = '';
                btn.style.color = '';
            }, 2000);
        }).catch(function() {
            // fallback
            var textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            btn.textContent = '✅ 已复制';
            setTimeout(function() { btn.textContent = '📋 复制代码'; }, 2000);
        });
    }

    // 暴露到全局供 onclick 使用
    window.copyFixCode = copyFixCode;

    // ---------- 初始化 ----------
    document.addEventListener('DOMContentLoaded', function() {
        initNavbar();
        initUpload();
        initReport();
        initRecharge();

        // 自动淡出 flash 消息
        $$('.flash-message').forEach(function(msg) {
            setTimeout(function() {
                msg.style.opacity = '0';
                msg.style.transition = 'opacity 0.5s ease';
                setTimeout(function() { msg.remove(); }, 500);
            }, 4000);
        });
    });

})();
