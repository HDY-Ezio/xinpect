#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
煋鉴 Xinpect 官网 v1.0 - Flask 后端
单文件实现，MVP 阶段
"""

import os
import re
import io
import zipfile
import tarfile
import json
import uuid
import sqlite3
import random
import hashlib
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, render_template, request, redirect, url_for,
                   session, flash, jsonify, g, make_response)
from werkzeug.security import generate_password_hash, check_password_hash

try:
    import requests as http_requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    print("WARNING: requests 库未安装，支付功能不可用")

# ============================================================
# 配置
# ============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'xinpect.db')

app = Flask(__name__)
app.secret_key = os.environ.get('XINPECT_SECRET', 'xinpect-dev-secret-key-change-in-prod')
app.config['MAX_CONTENT_LENGTH'] = 20 * 1024 * 1024  # 20MB 总上传限制

# 检测服务配置
SCANNER_URL = os.environ.get('SCANNER_URL', 'http://localhost:8620/scan')
# 门房服务（支付+用户权限中心）
MENFANG_BASE_URL = os.environ.get('MENFANG_BASE_URL', 'http://127.0.0.1:8612')

# 每日检测次数限制（v1.5后弱化，仅免费版保留每日1次限制）
DAILY_LIMIT_FREE = 3       # 未登录用户
DAILY_LIMIT_REGISTERED = 1  # 注册免费用户（v1.5改为1次/天，主要靠积分限制）

# ============================================================
# 积分制配置（v1.5）
# ============================================================

# 订阅档位每月积分赠送
SUBSCRIPTION_CREDITS = {
    'monthly':   {'name': '月卡',   'monthly_credits': 300,  'days': 30},
    'quarterly': {'name': '季卡',   'monthly_credits': 350,  'days': 90},   # 共1050
    'half_year': {'name': '半年卡', 'monthly_credits': 400,  'days': 180},  # 共2400
    'yearly':    {'name': '年卡',   'monthly_credits': 500,  'days': 365},  # 共6000
}

# 注册赠送积分（v1.5暂不使用，免费版纯次数限制，不送积分）
# SIGNUP_BONUS_CREDITS = 50

# 积分包商品（5档）
CREDIT_PACKS = {
    'pack_100':    {'name': '100积分',   'credits': 100,   'amount': 49,   'mf_plan': 'credit-100'},
    'pack_500':    {'name': '500积分',   'credits': 500,   'amount': 199,  'mf_plan': 'credit-500'},
    'pack_2000':   {'name': '2000积分',  'credits': 2000,  'amount': 599,  'mf_plan': 'credit-2000'},
    'pack_5000':   {'name': '5000积分',  'credits': 5000,  'amount': 1299, 'mf_plan': 'credit-5000'},
    'pack_15000':  {'name': '15000积分', 'credits': 15000, 'amount': 2999, 'mf_plan': 'credit-15000'},
}

# 扫描消耗配置（v1.5 按代码行数计费，简化版）
# 定价模型：成本驱动 + 67%毛利率锁定
# 公式：总百行数 × 百行单价，不足100行按100行算（无起步费）
SCAN_COST_BASE_FEE = 0               # 起步费（积分，0=无起步费）
SCAN_COST_PER_100_LINES_BASIC = 0.25 # 基础版百行单价（规则引擎，成本极低）
SCAN_COST_PER_100_LINES_FULL = 1     # 完整版百行单价（AI全增强）

# ============================================================
# 8 大脑维度定义
# ============================================================

BRAINS = [
    {'id': '1', 'name': '语法格式', 'icon': '📐', 'desc': '检查代码语法错误、格式规范、编码风格一致性。'},
    {'id': '2', 'name': '安全漏洞', 'icon': '🔒', 'desc': '检测注入攻击、硬编码密钥、敏感信息泄露等安全漏洞。'},
    {'id': '3', 'name': 'AI语义分析', 'icon': '🧠', 'desc': '基于AST深度分析代码语义，识别逻辑缺陷和异常模式。'},
    {'id': '4', 'name': '性能优化', 'icon': '⚡', 'desc': '识别性能瓶颈：低效循环、冗余计算、内存泄漏风险。'},
    {'id': '5', 'name': '依赖配置', 'icon': '📦', 'desc': '扫描第三方依赖版本、配置文件安全、构建脚本问题。'},
    {'id': '6', 'name': '代码质量', 'icon': '📊', 'desc': '圈复杂度、函数长度、嵌套层级、重复代码等可维护性指标。'},
    {'id': '7', 'name': '架构合规', 'icon': '🏗', 'desc': '模块耦合度、分层架构、循环依赖、全局状态等架构健康度。'},
    {'id': '8', 'name': '业务安全', 'icon': '🛡', 'desc': '支付安全、权限绕过、数据越权、业务逻辑漏洞等场景化检测。'},
]

# 三层分组 - 3S 评级体系
TIERS = [
    {
        'key': 'spec',
        'name': '规范层',
        'subtitle': '代码骨架',
        'brain_ids': ['1', '6', '7'],  # 语法格式 + 代码质量 + 架构合规
        'weights': {'1': 0.2, '6': 0.4, '7': 0.4},
        'desc': '代码的骨架是否规范、整洁、符合标准',
    },
    {
        'key': 'quality',
        'name': '质量层',
        'subtitle': '代码血肉',
        'brain_ids': ['3', '4', '5'],  # AI语义 + 性能 + 依赖配置
        'weights': {'3': 0.5, '4': 0.3, '5': 0.2},
        'desc': '代码的逻辑是否健壮、高效、可靠',
    },
    {
        'key': 'security',
        'name': '防护层',
        'subtitle': '代码皮肤',
        'brain_ids': ['2', '8'],  # 安全漏洞 + 业务安全
        'weights': {'2': 0.6, '8': 0.4},
        'desc': '代码的安全防护是否到位，能否抵御攻击',
    },
]

TIERS_MAP = {t['key']: t for t in TIERS}

BRAINS_MAP = {b['id']: b for b in BRAINS}

# ============================================================
# 数据库
# ============================================================

def get_db():
    """获取数据库连接，每个请求一个连接"""
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA journal_mode=WAL')
        g.db.execute('PRAGMA foreign_keys=ON')
    return g.db


@app.teardown_appcontext
def close_db(exception):
    """请求结束时关闭数据库连接"""
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    """初始化数据库表"""
    conn = sqlite3.connect(DB_PATH)
    conn.executescript('''
        -- 用户表
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_vip INTEGER DEFAULT 0,
            vip_expire_at TEXT,
            bonus_credits INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now', 'localtime'))
        );

        -- 扫描记录表
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id TEXT UNIQUE NOT NULL,
            user_id INTEGER,
            title TEXT,
            file_count INTEGER DEFAULT 0,
            files_meta TEXT,          -- JSON: 文件名列表
            results TEXT,             -- JSON: 完整检测结果
            score INTEGER DEFAULT 100,
            grade TEXT DEFAULT 'A',
            issue_count INTEGER DEFAULT 0,
            language TEXT,
            created_at TEXT DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        -- 订单表
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id TEXT UNIQUE NOT NULL,
            user_id INTEGER NOT NULL,
            plan_id TEXT,
            plan_name TEXT,
            order_type TEXT DEFAULT 'subscription',  -- subscription / topup
            amount REAL DEFAULT 0,
            status TEXT DEFAULT 'pending',  -- pending / paid / expired
            pay_method TEXT,
            paid_at TEXT,
            created_at TEXT DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        -- 每日使用量表（按 IP 或 user_id 统计，v1.5后弱化，仅供免费版使用）
        CREATE TABLE IF NOT EXISTS daily_usage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            user_id INTEGER,
            ip TEXT,
            count INTEGER DEFAULT 0,
            UNIQUE(date, user_id, ip)
        );

        -- 积分余额表（v1.5）
        CREATE TABLE IF NOT EXISTS user_credits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            balance INTEGER DEFAULT 0,
            total_earned INTEGER DEFAULT 0,
            total_spent INTEGER DEFAULT 0,
            updated_at TEXT DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        -- 积分流水表（v1.5）
        CREATE TABLE IF NOT EXISTS credit_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            type TEXT NOT NULL,       -- grant / purchase / consume / refund
            amount INTEGER NOT NULL,  -- 正数增加，负数减少
            balance_after INTEGER NOT NULL,
            ref_type TEXT,            -- subscription / credit_pack / scan / order
            ref_id TEXT,
            remark TEXT,
            created_at TEXT DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        -- 密码重置验证码表
        CREATE TABLE IF NOT EXISTS reset_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL,
            code TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            used INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now', 'localtime'))
        );

        CREATE INDEX IF NOT EXISTS idx_scans_user ON scans(user_id);
        CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
        CREATE INDEX IF NOT EXISTS idx_scans_scan_id ON scans(scan_id);
        CREATE INDEX IF NOT EXISTS idx_reset_codes_email ON reset_codes(email);
    ''')
    # 列迁移：兼容已有数据库，补字段
    try:
        conn.execute('ALTER TABLE users ADD COLUMN bonus_credits INTEGER DEFAULT 0')
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("ALTER TABLE orders ADD COLUMN order_type TEXT DEFAULT 'subscription'")
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("ALTER TABLE orders ADD COLUMN mf_order_id TEXT")
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("ALTER TABLE users ADD COLUMN mf_password_hash TEXT")
    except sqlite3.OperationalError:
        pass
    # v1.5: scans 表增加字段
    try:
        conn.execute("ALTER TABLE scans ADD COLUMN credits_spent INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("ALTER TABLE scans ADD COLUMN total_lines INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("ALTER TABLE scans ADD COLUMN scan_mode TEXT DEFAULT 'basic'")
    except sqlite3.OperationalError:
        pass
    # v1.5: 积分相关索引
    try:
        conn.execute('CREATE INDEX IF NOT EXISTS idx_user_credits_user ON user_credits(user_id)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_credit_tx_user ON credit_transactions(user_id)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_credit_tx_created ON credit_transactions(created_at)')
    except sqlite3.OperationalError:
        pass
    conn.commit()
    conn.close()


# ============================================================
# 工具函数
# ============================================================

def login_required(f):
    """登录装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('user_id'):
            flash('请先登录', 'warning')
            return redirect(url_for('login', next=request.path))
        return f(*args, **kwargs)
    return decorated_function


def get_current_user():
    """获取当前登录用户"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    db = get_db()
    return db.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()


def is_vip_user():
    """判断当前用户是否为付费会员"""
    user = get_current_user()
    if not user:
        return False
    if user['is_vip']:
        # 检查是否过期
        if user['vip_expire_at']:
            expire = datetime.strptime(user['vip_expire_at'], '%Y-%m-%d %H:%M:%S')
            if expire > datetime.now():
                return True
            else:
                # 过期了，更新状态
                db = get_db()
                db.execute('UPDATE users SET is_vip = 0 WHERE id = ?', (user['id'],))
                db.commit()
                return False
        return True  # 没设置过期时间，永久有效
    return False


# ============================================================
# 门房服务辅助函数（支付+权限中心）
# ============================================================
def _menfang_ensure_registered(email: str, password_hash: str) -> bool:
    """
    确保用户在门房服务中也注册了（用于支付对接）。
    password_hash 是 sha256 hex（和门房一致）。
    注册成功或已存在返回 True，失败返回 False（不阻塞网站流程）。
    """
    if not HAS_REQUESTS:
        return False
    try:
        resp = http_requests.post(
            f'{MENFANG_BASE_URL}/api/auth/register',
            json={'email': email, 'password_hash': password_hash},
            timeout=5
        )
        # 200=注册成功，409=已存在，都算成功
        return resp.status_code in (200, 409)
    except Exception as e:
        print(f'[门房] 同步注册失败 {email}: {e}')
        return False


def _menfang_login_with_hash(email: str, password_hash: str) -> str:
    """
    用 sha256 密码哈希登录门房获取 token。成功返回 token，失败返回空字符串。
    """
    if not HAS_REQUESTS:
        return ''
    try:
        resp = http_requests.post(
            f'{MENFANG_BASE_URL}/api/auth/login',
            json={'email': email, 'password_hash': password_hash},
            timeout=5
        )
        data = resp.json()
        if data.get('success'):
            return data.get('token', '')
    except Exception as e:
        print(f'[门房] 登录失败 {email}: {e}')
    return ''


def _menfang_create_pay_order_with_token(email: str, token: str, plan: str, amount: int) -> dict:
    """
    用 token 调用门房创建支付订单（推荐方式，避免传递密码）。
    返回: {success, order_id, qr_code_url, amount, message}
    """
    if not HAS_REQUESTS:
        return {'success': False, 'message': '支付服务未就绪'}
    try:
        headers = {}
        if token:
            headers['Authorization'] = f'Bearer {token}'
        resp = http_requests.post(
            f'{MENFANG_BASE_URL}/api/pay/create',
            json={
                'email': email,
                'plan': plan,
                'amount': amount
            },
            headers=headers,
            timeout=10
        )
        data = resp.json()
        if data.get('success'):
            return {
                'success': True,
                'order_id': data.get('order_id', ''),
                'qr_code_url': data.get('qr_code_url', ''),
                'amount': data.get('amount', amount)
            }
        else:
            return {'success': False, 'message': data.get('message', '创建订单失败')}
    except Exception as e:
        print(f'[门房] 创建支付订单失败: {e}')
        return {'success': False, 'message': '支付服务暂时不可用，请稍后重试'}


def _menfang_create_pay_order_with_hash(email: str, password_hash: str, plan: str, amount: int) -> dict:
    """
    用 password_hash 直接调用门房创建支付订单（兜底方式，token 都不可用时用）。
    返回: {success, order_id, qr_code_url, amount, message}
    """
    if not HAS_REQUESTS:
        return {'success': False, 'message': '支付服务未就绪'}
    try:
        resp = http_requests.post(
            f'{MENFANG_BASE_URL}/api/pay/create',
            json={
                'email': email,
                'password_hash': password_hash,
                'plan': plan,
                'amount': amount
            },
            timeout=10
        )
        data = resp.json()
        if data.get('success'):
            return {
                'success': True,
                'order_id': data.get('order_id', ''),
                'qr_code_url': data.get('qr_code_url', ''),
                'amount': data.get('amount', amount)
            }
        else:
            return {'success': False, 'message': data.get('message', '创建订单失败')}
    except Exception as e:
        print(f'[门房] 创建支付订单(hash方式)失败: {e}')
        return {'success': False, 'message': '支付服务暂时不可用，请稍后重试'}


def _menfang_get_order_status(order_id: str) -> dict:
    """
    查询门房订单支付状态。
    返回: {found, status, plan, amount, paid_at}
    """
    if not HAS_REQUESTS:
        return {'found': False, 'status': 'unknown'}
    try:
        resp = http_requests.get(
            f'{MENFANG_BASE_URL}/api/pay/order-status/{order_id}',
            timeout=5
        )
        if resp.status_code == 404:
            return {'found': False, 'status': 'not_found'}
        data = resp.json()
        return {
            'found': True,
            'status': data.get('status', 'unknown'),
            'plan': data.get('plan', ''),
            'amount': data.get('amount', 0),
            'paid_at': data.get('paid_at', '')
        }
    except Exception as e:
        print(f'[门房] 查询订单状态失败 {order_id}: {e}')
        return {'found': False, 'status': 'error'}


def get_daily_usage():
    """获取今日使用次数"""
    db = get_db()
    today = datetime.now().strftime('%Y-%m-%d')
    user_id = session.get('user_id')
    ip = request.remote_addr

    if user_id:
        row = db.execute(
            'SELECT count FROM daily_usage WHERE date = ? AND user_id = ?',
            (today, user_id)
        ).fetchone()
    else:
        row = db.execute(
            'SELECT count FROM daily_usage WHERE date = ? AND ip = ? AND user_id IS NULL',
            (today, ip)
        ).fetchone()

    return row['count'] if row else 0


def check_daily_limit():
    """检查是否超过每日限制，返回 (是否允许, 剩余次数)"""
    if is_vip_user():
        return True, -1  # VIP 无限

    usage = get_daily_usage()
    limit = DAILY_LIMIT_REGISTERED if session.get('user_id') else DAILY_LIMIT_FREE
    remaining = max(0, limit - usage)
    return remaining > 0, remaining


def increment_daily_usage():
    """增加今日使用次数"""
    db = get_db()
    today = datetime.now().strftime('%Y-%m-%d')
    user_id = session.get('user_id')
    ip = request.remote_addr

    if user_id:
        db.execute('''
            INSERT INTO daily_usage (date, user_id, ip, count)
            VALUES (?, ?, ?, 1)
            ON CONFLICT(date, user_id, ip)
            DO UPDATE SET count = count + 1
        ''', (today, user_id, ip))
    else:
        db.execute('''
            INSERT INTO daily_usage (date, user_id, ip, count)
            VALUES (?, NULL, ?, 1)
            ON CONFLICT(date, user_id, ip)
            DO UPDATE SET count = count + 1
        ''', (today, ip))
    db.commit()


# ============================================================
# 积分系统核心函数（v1.5）
# ============================================================

def get_user_credits(user_id):
    """获取用户积分余额，返回整数（不存在则返回0）"""
    if not user_id:
        return 0
    db = get_db()
    row = db.execute(
        'SELECT balance FROM user_credits WHERE user_id = ?',
        (user_id,)
    ).fetchone()
    return row['balance'] if row else 0


def _ensure_credit_account(db, user_id):
    """确保用户有积分账户记录（内部用，不单独提交事务）"""
    existing = db.execute(
        'SELECT id FROM user_credits WHERE user_id = ?',
        (user_id,)
    ).fetchone()
    if not existing:
        db.execute(
            'INSERT INTO user_credits (user_id, balance, total_earned, total_spent) VALUES (?, 0, 0, 0)',
            (user_id,)
        )


def grant_credits(user_id, amount, ref_type=None, ref_id=None, remark=''):
    """
    增加积分（写流水+更新余额，事务一致）。
    返回 True/False
    """
    if not user_id or amount <= 0:
        return False
    db = get_db()
    try:
        db.execute('BEGIN')
        _ensure_credit_account(db, user_id)

        # 更新余额和累计获得
        db.execute('''
            UPDATE user_credits
            SET balance = balance + ?,
                total_earned = total_earned + ?,
                updated_at = datetime('now', 'localtime')
            WHERE user_id = ?
        ''', (amount, amount, user_id))

        # 读取更新后的余额
        row = db.execute(
            'SELECT balance FROM user_credits WHERE user_id = ?',
            (user_id,)
        ).fetchone()
        balance_after = row['balance'] if row else 0

        # 写流水
        db.execute('''
            INSERT INTO credit_transactions
                (user_id, type, amount, balance_after, ref_type, ref_id, remark)
            VALUES (?, 'grant', ?, ?, ?, ?, ?)
        ''', (user_id, amount, balance_after, ref_type, str(ref_id) if ref_id else None, remark))

        db.execute('COMMIT')
        return True
    except Exception as e:
        db.execute('ROLLBACK')
        print(f'[积分] grant_credits 失败 user_id={user_id} amount={amount}: {e}')
        return False


def consume_credits(user_id, amount, ref_type=None, ref_id=None, remark=''):
    """
    扣减积分（事务一致）。余额不足返回 False，成功返回 True。
    """
    if not user_id or amount <= 0:
        return False
    db = get_db()
    try:
        db.execute('BEGIN')
        _ensure_credit_account(db, user_id)

        # 读取当前余额（加锁：SELECT FOR UPDATE 在SQLite中需要用IMMEDIATE事务）
        row = db.execute(
            'SELECT balance FROM user_credits WHERE user_id = ?',
            (user_id,)
        ).fetchone()
        current_balance = row['balance'] if row else 0

        if current_balance < amount:
            db.execute('ROLLBACK')
            return False

        # 扣减余额
        db.execute('''
            UPDATE user_credits
            SET balance = balance - ?,
                total_spent = total_spent + ?,
                updated_at = datetime('now', 'localtime')
            WHERE user_id = ?
        ''', (amount, amount, user_id))

        balance_after = current_balance - amount

        # 写流水（amount 为负数表示消耗）
        db.execute('''
            INSERT INTO credit_transactions
                (user_id, type, amount, balance_after, ref_type, ref_id, remark)
            VALUES (?, 'consume', -?, ?, ?, ?, ?)
        ''', (user_id, amount, balance_after, ref_type, str(ref_id) if ref_id else None, remark))

        db.execute('COMMIT')
        return True
    except Exception as e:
        db.execute('ROLLBACK')
        print(f'[积分] consume_credits 失败 user_id={user_id} amount={amount}: {e}')
        return False


def refund_credits(user_id, amount, ref_type=None, ref_id=None, remark=''):
    """
    退还积分（如扫描失败退款）。返回 True/False。
    """
    if not user_id or amount <= 0:
        return False
    db = get_db()
    try:
        db.execute('BEGIN')
        _ensure_credit_account(db, user_id)

        db.execute('''
            UPDATE user_credits
            SET balance = balance + ?,
                total_spent = total_spent - ?,
                updated_at = datetime('now', 'localtime')
            WHERE user_id = ?
        ''', (amount, amount, user_id))

        row = db.execute(
            'SELECT balance FROM user_credits WHERE user_id = ?',
            (user_id,)
        ).fetchone()
        balance_after = row['balance'] if row else 0

        db.execute('''
            INSERT INTO credit_transactions
                (user_id, type, amount, balance_after, ref_type, ref_id, remark)
            VALUES (?, 'refund', ?, ?, ?, ?, ?)
        ''', (user_id, amount, balance_after, ref_type, str(ref_id) if ref_id else None, remark))

        db.execute('COMMIT')
        return True
    except Exception as e:
        db.execute('ROLLBACK')
        print(f'[积分] refund_credits 失败 user_id={user_id} amount={amount}: {e}')
        return False


def calculate_scan_cost(total_lines, is_full_scan, language_type='standard'):
    """
    计算扫描消耗积分（按代码行数计费）。
    公式：总百行数 × 百行单价（无起步费）
    - 基础版（规则引擎）：0.25积分/百行
    - 完整版（AI全增强）：1积分/百行
    - 不足100行按100行算（向上取整到百行）
    - 语言系数 v1.0 暂不做，全按 standard × 1.0
    - 不足1积分按1积分计
    """
    if total_lines <= 0:
        return 0
    import math
    # 向上取整到百行
    hundred_lines = math.ceil(total_lines / 100)
    per_100 = SCAN_COST_PER_100_LINES_FULL if is_full_scan else SCAN_COST_PER_100_LINES_BASIC
    cost = SCAN_COST_BASE_FEE + hundred_lines * per_100
    # 向上取整，不足1积分按1积分计
    cost = max(1, math.ceil(cost))
    return int(cost)


def count_total_lines(files_dict):
    """
    统计所有源文件的总有效代码行数（简化版：非空行）。
    files_dict: {path: content} 字典
    返回：总代码行数
    """
    total = 0
    for content in files_dict.values():
        lines = content.split('\n')
        for line in lines:
            if line.strip():  # 非空行
                total += 1
    return total


def get_scan_mode(user_id):
    """
    返回用户的扫描模式：'basic' 或 'full'
    非会员 = basic，会员 = full
    """
    if not user_id:
        return 'basic'
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    if not user:
        return 'basic'
    # 判断是否为有效会员
    if user['is_vip']:
        if user['vip_expire_at']:
            try:
                expire = datetime.strptime(user['vip_expire_at'], '%Y-%m-%d %H:%M:%S')
                if expire > datetime.now():
                    return 'full'
            except (ValueError, TypeError):
                pass
        else:
            return 'full'  # 没设过期时间，永久有效
    return 'basic'


def check_credit_sufficient(user_id, estimated_cost):
    """检查积分是否足够，返回 bool"""
    if not user_id:
        return False
    balance = get_user_credits(user_id)
    return balance >= estimated_cost


def get_credit_transactions(user_id, limit=20):
    """获取用户积分流水（最近N条）"""
    if not user_id:
        return []
    db = get_db()
    rows = db.execute('''
        SELECT * FROM credit_transactions
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT ?
    ''', (user_id, limit)).fetchall()
    return [dict(r) for r in rows]


def score_to_grade(score):
    """分数转等级 - 单层最高只有S
    综合SSS由"三层全S"叠加得出，单层不设SS/SSS
    """
    if score >= 85:
        return 'S'
    elif score >= 65:
        return 'A'
    elif score >= 50:
        return 'B'
    elif score >= 30:
        return 'C'
    else:
        return 'D'

def score_color(score):
    """分数对应颜色"""
    if score >= 85:
        return '#10b981'  # success green
    elif score >= 60:
        return '#f59e0b'  # warning amber
    else:
        return '#ef4444'  # danger red


def calculate_tier_scores(all_issues, available_brain_ids=None, is_vip=True):
    """计算三层得分和各自评级
    层内 brain 加权平均（按权重配置），三层之间平权
    免费版：检测维度不全，单层评级上限为 A（保证评分严谨）
    专业版：单层最高 S，三层全 S 即为 SSS
    """
    tier_scores = {}
    for tier in TIERS:
        all_brain_ids = tier['brain_ids']
        weights = tier.get('weights', {})

        if available_brain_ids:
            tier_brain_ids = [bid for bid in all_brain_ids if bid in available_brain_ids]
        else:
            tier_brain_ids = list(all_brain_ids)

        if not tier_brain_ids:
            tier_scores[tier['key']] = {
                'score': None, 'grade': '🔒', 'brain_ids': tier_brain_ids,
                'issue_count': 0, 'locked': True
            }
            continue

        # 层内加权平均
        # 有 brain 被锁定时，按可用 brain 权重重新归一化
        available_weights = {bid: weights.get(bid, 1.0/len(all_brain_ids)) for bid in tier_brain_ids}
        total_weight = sum(available_weights.values())
        if total_weight > 0:
            normalized_weights = {bid: w/total_weight for bid, w in available_weights.items()}
        else:
            normalized_weights = {bid: 1.0/len(tier_brain_ids) for bid in tier_brain_ids}

        weighted_score = 0
        total_issues = 0
        for bid in tier_brain_ids:
            brain_issues = [i for i in all_issues if str(i.get('brain_id')) == bid]
            brain_score = calculate_dimension_score(brain_issues)
            weighted_score += brain_score * normalized_weights[bid]
            total_issues += len(brain_issues)

        raw_score = int(round(weighted_score))
        grade = score_to_grade(raw_score)

        # 免费版单层上限 A：维度不全，不给最高评价
        if not is_vip and grade == 'S':
            grade = 'A'

        tier_scores[tier['key']] = {
            'score': raw_score,
            'grade': grade,
            'brain_ids': tier_brain_ids,
            'issue_count': total_issues,
            'locked': False,
        }
    return tier_scores

def calculate_overall_grade(tier_scores):
    """三层综合评级
    规则：统计S的数量决定前缀，非S层取最低等级作为后缀
    - 3个S → SSS
    - 2个S → SS
    - 1个S → S
    - 0个S → 取最差等级字母
    """
    unlocked = [v for v in tier_scores.values() if not v.get('locked') and v.get('score') is not None]
    if not unlocked:
        return 'S'

    grade_order = {'S': 4, 'A': 3, 'B': 2, 'C': 1, 'D': 0}

    s_count = sum(1 for t in unlocked if t['grade'] == 'S')
    total = len(unlocked)

    # 全 S → 根据总层数拼 SSS/SS/S
    if s_count == total:
        if total >= 3:
            return 'SSS'
        elif total == 2:
            return 'SS'
        else:
            return 'S'

    # 部分 S → S 数量前缀 + 非S最低等级后缀
    if s_count > 0:
        non_s_grades = [t['grade'] for t in unlocked if t['grade'] != 'S']
        worst_non_s = min(non_s_grades, key=lambda g: grade_order.get(g, 99))
        if s_count >= 2:
            return f'SS{worst_non_s}'
        else:
            return f'S{worst_non_s}'

    # 没有 S → 取最差等级
    worst = min(unlocked, key=lambda t: grade_order.get(t['grade'], 99))
    return worst['grade']


def get_grade_base(grade_str):
    """从等级字符串中提取基础等级（短板字母）。
    新格式：B++ / S+ / A  → 取首字母
    旧格式：SSA / SAB / AB  → 取最差字母（按S>A>B>C>D排序，越靠后越差）
    单字母：直接返回
    """
    if not grade_str:
        return 'D'
    grade_str = str(grade_str).strip().upper()
    # 单字母直接返回
    if len(grade_str) == 1 and grade_str in 'SABCD':
        return grade_str
    # 新格式：以+结尾，首字母是短板
    if '+' in grade_str:
        first = grade_str[0]
        if first in 'SABCD':
            return first
    # 旧格式：多个字母，找最差的
    order = ['S', 'A', 'B', 'C', 'D']
    worst_rank = -1
    for ch in grade_str:
        if ch in order:
            rank = order.index(ch)
            if rank > worst_rank:
                worst_rank = rank
    if worst_rank >= 0:
        return order[worst_rank]
    return 'D'


@app.template_filter('grade_base')
def grade_base_filter(grade_str):
    return get_grade_base(grade_str)


def calculate_score(issues, available_brain_ids=None):
    """
    加权扣分制计算综合得分
    
    扣分规则：
    - Blocker (critical): 每个 -10 分（不设上限）
    - High: 每个 -5 分（不设上限）
    - Medium: 每个 -3 分（最多扣 30 分）
    - Low: 每个 -0.5 分（最多扣 20 分）
    - score = max(0, 100 - 总扣分)
    
    参数:
        issues: 问题列表，每个问题需要有 severity 字段
        available_brain_ids: 可用的大脑 ID 列表（用于免费用户只计算 B1~B3）
    """
    if available_brain_ids:
        issues = [i for i in issues if str(i.get('brain_id', '')) in available_brain_ids]

    critical_count = sum(1 for i in issues if i.get('severity') == 'critical')
    high_count = sum(1 for i in issues if i.get('severity') == 'high')
    medium_count = sum(1 for i in issues if i.get('severity') == 'medium')
    low_count = sum(1 for i in issues if i.get('severity') == 'low')

    # 计算扣分
    deduction_critical = critical_count * 10       # 不设上限
    deduction_high = high_count * 5                # 不设上限
    deduction_medium = min(medium_count * 3, 30)   # 最多扣 30 分
    deduction_low = min(low_count * 0.5, 20)       # 最多扣 20 分

    total_deduction = deduction_critical + deduction_high + deduction_medium + deduction_low
    score = max(0, int(round(100 - total_deduction)))

    return score


def calculate_dimension_score(issues):
    """计算单个维度的得分（使用同一套扣分公式）"""
    return calculate_score(issues)


def severity_label(severity):
    """严重程度中文标签"""
    labels = {
        'critical': '严重',
        'high': '高危',
        'medium': '中等',
        'low': '轻微',
    }
    return labels.get(severity, severity)


# ============================================================
# Mock 检测服务（等 scanner 开发完再接真实接口）
# ============================================================

MOCK_RULES = {
    '1': [  # B1 语法规范
        {'rule_id': 'B1001', 'title': '行长度超过 120 字符', 'severity': 'low',
         'description': '代码行过长会降低可读性，建议拆分为多行。',
         'suggestion': '将长行拆分为多行，使用括号或续行符保持代码清晰。'},
        {'rule_id': 'B1002', 'title': '变量命名不符合规范', 'severity': 'low',
         'description': '变量名应使用 snake_case 风格（Python）或 camelCase（JS）。',
         'suggestion': '将变量名修改为符合语言约定的命名风格。'},
        {'rule_id': 'B1003', 'title': '缺少函数文档字符串', 'severity': 'low',
         'description': '公共函数应该有 docstring 说明其用途、参数和返回值。',
         'suggestion': '为函数添加清晰的文档字符串。'},
        {'rule_id': 'B1004', 'title': '缩进不一致', 'severity': 'medium',
         'description': '代码中混用了空格和 Tab 缩进，或缩进数量不一致。',
         'suggestion': '统一使用 4 空格（或项目约定的数量）进行缩进。'},
    ],
    '2': [  # B2 代码缺陷
        {'rule_id': 'B2001', 'title': '可能的空指针引用', 'severity': 'high',
         'description': '变量可能为 None/null，但在使用前未进行空值检查。',
         'suggestion': '在使用前添加空值检查，或使用安全调用运算符。'},
        {'rule_id': 'B2002', 'title': '异常被静默吞掉', 'severity': 'high',
         'description': '捕获了异常但没有任何处理逻辑，可能掩盖严重问题。',
         'suggestion': '至少记录日志，或重新抛出异常，不要静默吞掉。'},
        {'rule_id': 'B2003', 'title': '资源未正确释放', 'severity': 'medium',
         'description': '打开的文件/数据库连接/网络连接可能未被正确关闭。',
         'suggestion': '使用 with 语句（Python）或 try-finally 确保资源释放。'},
        {'rule_id': 'B2004', 'title': '除零风险', 'severity': 'critical',
         'description': '除法运算的除数可能为零，会导致运行时崩溃。',
         'suggestion': '在除法运算前检查除数是否为零。'},
        {'rule_id': 'B2005', 'title': '逻辑表达式永真/永假', 'severity': 'medium',
         'description': '条件表达式的结果总是 true 或总是 false，可能是逻辑错误。',
         'suggestion': '检查条件表达式的逻辑是否正确。'},
    ],
    '3': [  # B3 安全扫描
        {'rule_id': 'B3001', 'title': 'SQL 注入风险', 'severity': 'critical',
         'description': '使用字符串拼接构造 SQL 查询，存在 SQL 注入漏洞。',
         'suggestion': '使用参数化查询或 ORM，不要直接拼接 SQL 字符串。'},
        {'rule_id': 'B3002', 'title': '硬编码敏感信息', 'severity': 'high',
         'description': '代码中硬编码了密码、密钥、token 等敏感信息。',
         'suggestion': '使用环境变量或密钥管理服务存储敏感信息。'},
        {'rule_id': 'B3003', 'title': 'XSS 跨站脚本风险', 'severity': 'high',
         'description': '用户输入未经转义直接输出到 HTML，可能导致 XSS 攻击。',
         'suggestion': '对所有用户输入进行 HTML 转义后再输出。'},
        {'rule_id': 'B3004', 'title': '不安全的随机数', 'severity': 'medium',
         'description': '使用了不安全的伪随机数生成器用于安全场景。',
         'suggestion': '在安全相关场景使用加密安全的随机数生成器。'},
    ],
    '4': [  # B4 性能优化
        {'rule_id': 'B4001', 'title': '循环中重复计算', 'severity': 'medium',
         'description': '在循环体内重复执行可以提升到循环外的计算。',
         'suggestion': '将循环内不变的计算提升到循环外部。'},
        {'rule_id': 'B4002', 'title': 'N+1 查询问题', 'severity': 'high',
         'description': '在循环中执行数据库查询，可能导致严重的性能问题。',
         'suggestion': '使用批量查询（IN 查询）或 JOIN 替代循环查询。'},
        {'rule_id': 'B4003', 'title': '不必要的深拷贝', 'severity': 'low',
         'description': '对大数据对象进行了不必要的深拷贝，消耗内存和时间。',
         'suggestion': '评估是否真的需要深拷贝，考虑使用浅拷贝或引用。'},
    ],
    '5': [  # B5 架构设计
        {'rule_id': 'B5001', 'title': '函数职责过多', 'severity': 'medium',
         'description': '函数承担了过多职责，违反单一职责原则。',
         'suggestion': '将函数拆分为多个小函数，每个函数只做一件事。'},
        {'rule_id': 'B5002', 'title': '模块耦合度过高', 'severity': 'medium',
         'description': '模块间依赖关系复杂，难以独立修改和测试。',
         'suggestion': '引入抽象层，降低模块间的耦合度。'},
        {'rule_id': 'B5003', 'title': '上帝类/上帝函数', 'severity': 'high',
         'description': '单个类或函数承担了整个系统的大部分逻辑。',
         'suggestion': '按职责拆分为多个类/函数，遵循单一职责原则。'},
    ],
    '6': [  # B6 复杂度
        {'rule_id': 'B6001', 'title': '圈复杂度过高', 'severity': 'high',
         'description': '函数的圈复杂度超过阈值（>15），难以理解和测试。',
         'suggestion': '拆分复杂函数，减少条件分支和循环嵌套。'},
        {'rule_id': 'B6002', 'title': '嵌套层级过深', 'severity': 'medium',
         'description': '条件或循环嵌套超过 4 层，降低代码可读性。',
         'suggestion': '使用提前返回、卫语句等方式减少嵌套。'},
        {'rule_id': 'B6003', 'title': '重复代码片段', 'severity': 'medium',
         'description': '检测到多处相似的代码片段，存在重复。',
         'suggestion': '提取公共逻辑为函数或工具类，消除重复代码。'},
    ],
    '7': [  # B7 最佳实践
        {'rule_id': 'B7001', 'title': '缺少单元测试', 'severity': 'low',
         'description': '该函数/模块没有对应的单元测试。',
         'suggestion': '为核心逻辑添加单元测试，确保代码质量。'},
        {'rule_id': 'B7002', 'title': '魔法数字未命名', 'severity': 'low',
         'description': '代码中出现未命名的魔法数字，含义不明确。',
         'suggestion': '将魔法数字定义为有意义的常量。'},
        {'rule_id': 'B7003', 'title': '函数参数过多', 'severity': 'medium',
         'description': '函数参数超过 5 个，调用和维护成本高。',
         'suggestion': '考虑使用配置对象或数据类封装参数。'},
    ],
    '8': [  # B8 依赖扫描
        {'rule_id': 'B8001', 'title': '依赖版本存在已知漏洞', 'severity': 'critical',
         'description': '检测到使用的第三方库版本存在 CVE 安全漏洞。',
         'suggestion': '升级到最新的安全版本，或寻找替代方案。'},
        {'rule_id': 'B8002', 'title': '依赖版本过旧', 'severity': 'medium',
         'description': '使用的依赖库版本已过时，可能缺少重要更新。',
         'suggestion': '升级依赖到较新的稳定版本。'},
        {'rule_id': 'B8003', 'title': '许可证风险', 'severity': 'low',
         'description': '依赖的许可证可能与项目许可证不兼容。',
         'suggestion': '审查依赖许可证，确保与项目使用方式兼容。'},
    ],
}


def mock_scan(files_dict, brain_ids, language='auto'):
    """
    模拟检测结果（等 scanner 开发完成替换为真实调用）
    
    参数:
        files_dict: {file_path: content} 字典
        brain_ids: 要运行的大脑 ID 列表
        language: 编程语言
    
    返回:
        dict: 检测结果
    """
    all_issues = []
    file_paths = list(files_dict.keys())

    # 模拟：每个大脑生成一些问题
    for brain_id in brain_ids:
        rules = MOCK_RULES.get(brain_id, [])
        if not rules:
            continue

        # 随机生成 1-5 个问题
        num_issues = random.randint(1, min(5, len(rules)))
        selected_rules = random.sample(rules, num_issues)

        for rule in selected_rules:
            # 随机选择一个文件和行号
            file_path = random.choice(file_paths) if file_paths else 'unknown'
            content = files_dict.get(file_path, '')
            lines = content.split('\n') if content else ['']
            line_num = random.randint(1, max(1, len(lines)))

            # 获取代码片段（前后各 2 行）
            start_line = max(0, line_num - 2)
            end_line = min(len(lines), line_num + 2)
            snippet_lines = []
            for i in range(start_line, end_line):
                prefix = '> ' if i + 1 == line_num else '  '
                snippet_lines.append(f"{prefix}{i+1:4d}: {lines[i]}")
            code_snippet = '\n'.join(snippet_lines)

            issue = {
                'brain_id': brain_id,
                'brain_name': BRAINS_MAP.get(brain_id, {}).get('name', ''),
                'rule_id': rule['rule_id'],
                'title': rule['title'],
                'severity': rule['severity'],
                'severity_label': severity_label(rule['severity']),
                'description': rule['description'],
                'suggestion': rule['suggestion'],
                'file': file_path,
                'line': line_num,
                'code_snippet': code_snippet,
            }
            all_issues.append(issue)

    # 按严重程度排序
    severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
    all_issues.sort(key=lambda x: (severity_order.get(x['severity'], 99), x['brain_id']))

    return {
        'brains': brain_ids,
        'language': language,
        'issues': all_issues,
        'file_count': len(files_dict),
        'total_issues': len(all_issues),
    }


def call_scanner(files_dict, brain_ids, language='auto', scan_mode='full', is_vip=False):
    """
    调用 xinpect-scanner v5 检测服务

    scanner v5 返回格式:
        {status, total_elapsed, results: {brain_id: {score, issues, ...}}}
    每个 issue 字段: check_id, name, severity, file, line, message, suggestion
    AI增强字段: ai_source, ai_confidence, ai_analysis, ai_fix_suggestion, ai_exploitability
    """
    try:
        import requests
        resp = requests.post(SCANNER_URL, json={
            'code_files': files_dict,
            'brain_ids': brain_ids,
            'scan_mode': scan_mode,
            'is_vip': is_vip,
        }, timeout=180)
        resp.raise_for_status()
        raw = resp.json()

        # 格式适配：把按 brain 分组的 issues 拍平成前端需要的格式
        all_issues = []
        results_by_brain = raw.get('results', {})

        for bid in brain_ids:
            brain_result = results_by_brain.get(str(bid), {})
            brain_issues = brain_result.get('issues', [])
            brain_name = BRAINS_MAP.get(str(bid), {}).get('name', f'B{bid}')

            for issue in brain_issues:
                # 提取代码片段（从原文件内容里取）
                file_path = issue.get('file', '')
                line_num = issue.get('line', 0)
                content = files_dict.get(file_path, '')
                code_snippet = ''
                if content and line_num:
                    lines = content.split('\n')
                    start = max(0, line_num - 3)
                    end = min(len(lines), line_num + 2)
                    snippet_lines = []
                    for i in range(start, end):
                        marker = '> ' if i + 1 == line_num else '  '
                        snippet_lines.append(f"{marker}{i+1:4d}: {lines[i]}")
                    code_snippet = '\n'.join(snippet_lines)

                all_issues.append({
                    'brain_id': str(bid),
                    'brain_name': brain_name,
                    'rule_id': issue.get('check_id', ''),
                    'title': issue.get('name', issue.get('check_id', '')),
                    'severity': issue.get('severity', 'medium'),
                    'severity_label': severity_label(issue.get('severity', 'medium')),
                    'description': issue.get('message', ''),
                    'suggestion': issue.get('suggestion', ''),
                    'file': file_path,
                    'line': line_num,
                    'code_snippet': code_snippet,
                    'category': issue.get('category', ''),
                    # AI 增强字段
                    'ai_source': issue.get('ai_source', 'rule'),
                    'ai_confidence': issue.get('ai_confidence'),
                    'ai_analysis': issue.get('ai_analysis', ''),
                    'ai_fix_suggestion': issue.get('ai_fix_suggestion', ''),
                    'ai_exploitability': issue.get('ai_exploitability', ''),
                })

        # 按严重程度排序
        sev_order = {'blocker': -1, 'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}
        all_issues.sort(key=lambda x: (sev_order.get(x.get('severity', ''), 99),
                                        str(x.get('brain_id', ''))))

        return {
            'brains': brain_ids,
            'language': language,
            'issues': all_issues,
            'file_count': len(files_dict),
            'total_issues': len(all_issues),
            'scan_time': raw.get('total_elapsed', 0),
            'version': raw.get('version', '5.0'),
            'ai_stats': raw.get('ai_stats', {}),
            'ai_elapsed': raw.get('ai_elapsed', 0),
        }
    except Exception as e:
        app.logger.error(f'Scanner call failed: {e}')
        import traceback
        app.logger.error(traceback.format_exc())
        # fallback 到 mock，保证网站可用
        return mock_scan(files_dict, brain_ids, language)


# ============================================================
# 页面路由
# ============================================================

@app.route('/')
def index():
    """首页"""
    return render_template('index.html', brains=BRAINS)


@app.route('/pricing')
def pricing_page():
    """定价页"""
    vip = is_vip_user()
    user = get_current_user()
    return render_template('pricing.html', is_vip=vip, user=user)


@app.route('/upload')
def upload_page():
    """上传页"""
    vip = is_vip_user()
    user = get_current_user()
    user_id = user['id'] if user else None

    if vip:
        session['is_vip'] = True
        remaining = 0
        scan_mode = 'full'
        # v1.5: 会员才显示积分余额
        credit_balance = get_user_credits(user_id) if user_id else 0
    else:
        session['is_vip'] = False
        allowed, remaining = check_daily_limit()
        scan_mode = 'basic'
        credit_balance = 0  # 免费版无积分

    return render_template('upload.html',
                           daily_remaining=remaining,
                           credit_balance=credit_balance,
                           scan_mode=scan_mode,
                           is_vip=vip)


@app.route('/api/scan/estimate', methods=['POST'])
def api_scan_estimate():
    """
    预估扫描积分消耗（不上传服务器扫描，仅计算文件行数和积分）
    前端可以在用户选择文件后调用此接口展示预估费用
    返回：{file_count, total_lines, credits_cost, scan_mode, credit_balance}
    """
    # 收集文件
    files_dict = {}
    CODE_EXTS = {'.py', '.js', '.ts', '.tsx', '.jsx', '.java', '.go', '.cpp', '.c',
                 '.h', '.cs', '.php', '.rb', '.rs', '.swift', '.kt', '.wxml', '.wxss',
                 '.vue', '.html', '.htm', '.scss', '.less', '.css', '.sass',
                 '.json', '.yaml', '.yml', '.toml', '.ini', '.sh', '.bash'}

    def _quick_extract_archive(file_storage):
        """快速从压缩包中提取代码文件统计行数"""
        result = {}
        filename = file_storage.filename.lower()
        data = file_storage.read()
        try:
            if filename.endswith('.zip'):
                with zipfile.ZipFile(io.BytesIO(data)) as zf:
                    for info in zf.infolist():
                        if info.is_dir():
                            continue
                        name = info.filename
                        if any(x in name for x in ('__pycache__', 'node_modules', '.git/',
                                                    'dist/', 'build/', '.venv', 'venv/',
                                                    '.DS_Store', 'Thumbs.db')):
                            continue
                        if name.startswith('.') or '/.' in name:
                            continue
                        ext = os.path.splitext(name)[1].lower()
                        if ext in CODE_EXTS:
                            try:
                                with zf.open(info) as f:
                                    content = f.read().decode('utf-8', errors='replace')
                                parts = name.split('/', 1)
                                display_name = parts[1] if len(parts) > 1 else parts[0]
                                result[display_name] = content
                            except Exception:
                                pass
            elif filename.endswith(('.tar.gz', '.tgz', '.tar')):
                with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as tf:
                    for member in tf.getmembers():
                        if not member.isfile():
                            continue
                        name = member.name
                        if any(x in name for x in ('__pycache__', 'node_modules', '.git/',
                                                    'dist/', 'build/', '.venv', 'venv/',
                                                    '.DS_Store', 'Thumbs.db')):
                            continue
                        if name.startswith('.') or '/.' in name:
                            continue
                        ext = os.path.splitext(name)[1].lower()
                        if ext in CODE_EXTS:
                            try:
                                f = tf.extractfile(member)
                                if f:
                                    content = f.read().decode('utf-8', errors='replace')
                                    parts = name.split('/', 1)
                                    display_name = parts[1] if len(parts) > 1 else parts[0]
                                    result[display_name] = content
                            except Exception:
                                pass
        except Exception:
            pass
        return result

    # 方式1：上传文件
    uploaded_files = request.files.getlist('files')
    if uploaded_files and uploaded_files[0].filename:
        for f in uploaded_files:
            if f and f.filename:
                fname_lower = f.filename.lower()
                if fname_lower.endswith(('.zip', '.tar.gz', '.tgz', '.tar')):
                    extracted = _quick_extract_archive(f)
                    files_dict.update(extracted)
                else:
                    content = f.read().decode('utf-8', errors='replace')
                    files_dict[f.filename] = content

    # 方式2：粘贴代码
    code = request.form.get('code', '').strip()
    if code:
        filename = request.form.get('filename', 'code.txt') or 'code.txt'
        files_dict[filename] = code

    if not files_dict:
        return jsonify({'error': '请上传文件或粘贴代码'}), 400

    file_count = len(files_dict)
    total_lines = count_total_lines(files_dict)

    vip = is_vip_user()
    is_full_scan = vip
    scan_mode = 'full' if is_full_scan else 'basic'

    user = get_current_user()
    user_id = user['id'] if user else None

    # v1.5: 会员返回积分预估，免费版返回次数限制信息
    if vip:
        credits_cost = calculate_scan_cost(total_lines, is_full_scan=True)
        credit_balance = get_user_credits(user_id)
        sufficient = check_credit_sufficient(user_id, credits_cost)
        return jsonify({
            'file_count': file_count,
            'total_lines': total_lines,
            'scan_mode': scan_mode,
            'is_vip': True,
            'credits_cost': credits_cost,
            'credit_balance': credit_balance,
            'is_sufficient': sufficient,
            'base_fee': SCAN_COST_BASE_FEE,
            'per_100_lines': SCAN_COST_PER_100_LINES_FULL,
        })
    else:
        # 免费版：不涉及积分，返回次数和文件数限制
        allowed, remaining = check_daily_limit()
        return jsonify({
            'file_count': file_count,
            'total_lines': total_lines,
            'scan_mode': scan_mode,
            'is_vip': False,
            'daily_remaining': remaining,
            'daily_allowed': allowed,
            'free_file_limit': 30,
            'over_file_limit': file_count > 30,
        })


@app.route('/scan', methods=['POST'])
@app.route('/api/scan/submit', methods=['POST'])
def scan():
    """发起检测（返回 JSON）"""
    # 检查每日限制
    allowed, remaining = check_daily_limit()
    if not allowed:
        return jsonify({'error': '今日检测次数已用完，请明天再试或升级会员'}), 429

    # 收集文件
    files_dict = {}

    # 支持的代码文件扩展名
    CODE_EXTS = {'.py', '.js', '.ts', '.tsx', '.jsx', '.java', '.go', '.cpp', '.c',
                 '.h', '.cs', '.php', '.rb', '.rs', '.swift', '.kt', '.wxml', '.wxss',
                 '.vue', '.html', '.htm', '.scss', '.less', '.css', '.sass',
                 '.json', '.yaml', '.yml', '.toml', '.ini', '.sh', '.bash'}

    def _extract_archive(file_storage):
        """从压缩包中提取代码文件，返回 {path: content} 字典"""
        result = {}
        filename = file_storage.filename.lower()
        data = file_storage.read()

        try:
            if filename.endswith('.zip'):
                with zipfile.ZipFile(io.BytesIO(data)) as zf:
                    for info in zf.infolist():
                        if info.is_dir():
                            continue
                        # 跳过隐藏文件、__pycache__、node_modules 等
                        name = info.filename
                        if any(x in name for x in ('__pycache__', 'node_modules', '.git/',
                                                    'dist/', 'build/', '.venv', 'venv/',
                                                    '.DS_Store', 'Thumbs.db')):
                            continue
                        if name.startswith('.') or '/.' in name:
                            continue
                        ext = os.path.splitext(name)[1].lower()
                        if ext in CODE_EXTS:
                            try:
                                with zf.open(info) as f:
                                    content = f.read().decode('utf-8', errors='replace')
                                # 去掉 zip 最外层目录前缀，让路径更干净
                                parts = name.split('/', 1)
                                display_name = parts[1] if len(parts) > 1 else parts[0]
                                result[display_name] = content
                            except Exception:
                                pass  # 单个文件解析失败不影响整体

            elif filename.endswith(('.tar.gz', '.tgz', '.tar')):
                with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as tf:
                    for member in tf.getmembers():
                        if not member.isfile():
                            continue
                        name = member.name
                        if any(x in name for x in ('__pycache__', 'node_modules', '.git/',
                                                    'dist/', 'build/', '.venv', 'venv/',
                                                    '.DS_Store', 'Thumbs.db')):
                            continue
                        if name.startswith('.') or '/.' in name:
                            continue
                        ext = os.path.splitext(name)[1].lower()
                        if ext in CODE_EXTS:
                            try:
                                f = tf.extractfile(member)
                                if f:
                                    content = f.read().decode('utf-8', errors='replace')
                                    parts = name.split('/', 1)
                                    display_name = parts[1] if len(parts) > 1 else parts[0]
                                    result[display_name] = content
                            except Exception:
                                pass  # 单个文件解析失败不影响整体
        except Exception as e:
            # 解压失败就跳过，不让整个扫描挂掉
            pass

        return result

    # 方式1：上传文件（支持单文件、多文件、zip/tar.gz 压缩包）
    uploaded_files = request.files.getlist('files')
    if uploaded_files and uploaded_files[0].filename:
        for f in uploaded_files:
            if f and f.filename:
                fname_lower = f.filename.lower()
                # 压缩包：解压后扫描里面的代码文件
                if fname_lower.endswith(('.zip', '.tar.gz', '.tgz', '.tar')):
                    extracted = _extract_archive(f)
                    files_dict.update(extracted)
                else:
                    # 普通代码文件：直接读
                    content = f.read().decode('utf-8', errors='replace')
                    files_dict[f.filename] = content

    # 方式2：粘贴代码
    code = request.form.get('code', '').strip()
    if code:
        filename = request.form.get('filename', 'code.txt') or 'code.txt'
        files_dict[filename] = code

    if not files_dict:
        return jsonify({'error': '请上传文件或粘贴代码'}), 400

    language = request.form.get('language', 'auto')

    # 判断权限
    vip = is_vip_user()
    user_id = session.get('user_id')
    is_full_scan = vip  # 会员=完整版，非会员=基础版
    scan_mode = 'full' if is_full_scan else 'basic'

    if is_full_scan:
        brain_ids = ['1', '2', '3', '4', '5', '6', '7', '8']
    else:
        brain_ids = ['1', '2', '3']  # 免费用户只有 B1~B3

    file_count = len(files_dict)
    total_lines = count_total_lines(files_dict)

    # v1.5: 权限分支
    # 会员：走积分制，扫描前扣积分
    # 免费版（含未登录+登录免费用户）：纯次数限制，不扣积分
    if vip:
        # 会员：积分扣减
        credits_cost = calculate_scan_cost(total_lines, is_full_scan=True)
        if not check_credit_sufficient(user_id, credits_cost):
            balance = get_user_credits(user_id)
            return jsonify({
                'error': f'积分不足，本次扫描需 {credits_cost} 积分，当前余额 {balance} 积分',
                'credits_needed': credits_cost,
                'credits_balance': balance,
                'total_lines': total_lines,
                'scan_mode': scan_mode,
            }), 402

        # 扣减积分（扫描前先扣，防薅羊毛）
        success = consume_credits(user_id, credits_cost,
                                  ref_type='scan_pre', ref_id='pending',
                                  remark=f'扫描预扣：{total_lines}行，{file_count}个文件，完整版')
        if not success:
            return jsonify({'error': '积分扣减失败，请重试'}), 500
    else:
        # 免费版：每日次数限制，不扣积分
        # 免费版文件数上限：30个
        if file_count > 30:
            return jsonify({'error': '免费版每次最多扫描30个文件，升级会员可解锁更多'}), 403

        allowed, remaining = check_daily_limit()
        if not allowed:
            return jsonify({'error': '今日免费检测次数已用完，请明天再试或升级会员'}), 429
        credits_cost = 0

    # 调用检测（会员传 full 模式启用AI增强，免费版传 basic 模式跳过AI）
    scan_mode_for_scanner = 'full' if vip else 'basic'
    results = call_scanner(files_dict, brain_ids, language, scan_mode=scan_mode_for_scanner, is_vip=vip)

    # 计算三层得分和综合评级（免费用户只按 B1~B3 计算）
    avail_brains = None if vip else ['1','2','3']
    score = calculate_score(results['issues'], available_brain_ids=avail_brains)
    tier_scores = calculate_tier_scores(results['issues'], available_brain_ids=avail_brains, is_vip=vip)
    grade = calculate_overall_grade(tier_scores)

    # 生成 scan_id
    scan_id = hashlib.sha256(f"{uuid.uuid4()}{datetime.now().isoformat()}".encode()).hexdigest()[:32]

    # 构建标题
    first_file = list(files_dict.keys())[0] if files_dict else 'unknown'
    if len(files_dict) > 1:
        title = f"{first_file} 等 {len(files_dict)} 个文件"
    else:
        title = first_file

    # 保存到数据库
    db = get_db()
    db.execute('''
        INSERT INTO scans (scan_id, user_id, title, file_count, files_meta,
                          results, score, grade, issue_count, language,
                          credits_spent, total_lines, scan_mode)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        scan_id,
        user_id,
        title,
        len(files_dict),
        json.dumps(list(files_dict.keys()), ensure_ascii=False),
        json.dumps(results, ensure_ascii=False),
        score,
        grade,
        results['total_issues'],
        language,
        credits_cost if user_id else 0,
        total_lines,
        scan_mode,
    ))

    # v1.5: 会员用户更新积分流水 ref_id
    if vip and user_id:
        last_tx = db.execute('''
            SELECT id FROM credit_transactions
            WHERE user_id = ? AND type = 'consume' AND ref_type = 'scan_pre'
            ORDER BY id DESC LIMIT 1
        ''', (user_id,)).fetchone()
        if last_tx:
            db.execute('''
                UPDATE credit_transactions
                SET ref_type = 'scan', ref_id = ?, remark = ?
                WHERE id = ?
            ''', (scan_id, f'扫描消耗：{total_lines}行，{file_count}个文件，完整版', last_tx['id']))

    db.commit()

    # 免费版用户增加每日使用次数（会员不统计daily_usage）
    if not vip:
        increment_daily_usage()

    return jsonify({
        'scan_id': scan_id,
        'score': score,
        'grade': grade,
        'total_issues': results['total_issues'],
        'credits_spent': credits_cost if user_id else 0,
        'credits_balance': get_user_credits(user_id) if user_id else 0,
    })


@app.route('/report/<scan_id>')
def report_page(scan_id):
    """报告页"""
    db = get_db()
    scan = db.execute('SELECT * FROM scans WHERE scan_id = ?', (scan_id,)).fetchone()

    if not scan:
        flash('检测报告不存在', 'error')
        return redirect(url_for('index'))

    # 权限检查：如果是用户自己的检测，或者未登录用户的检测（通过 session 标记）
    # MVP 阶段：公开可访问（方便分享），后续可加权限控制

    results = json.loads(scan['results']) if scan['results'] else {'issues': []}
    all_issues = results.get('issues', [])
    vip = is_vip_user()

    # 构建维度数据
    dimensions = []
    for brain in BRAINS:
        brain_issues = [i for i in all_issues if str(i.get('brain_id')) == brain['id']]
        is_locked = (not vip) and (brain['id'] not in ['1', '2', '3'])

        if is_locked:
            dimensions.append({
                'id': brain['id'],
                'name': brain['name'],
                'score': '—',
                'score_color': '#6b7280',
                'issues_count': '🔒',
                'locked': True,
            })
        else:
            dim_score = calculate_dimension_score(brain_issues)
            dimensions.append({
                'id': brain['id'],
                'name': brain['name'],
                'score': dim_score,
                'score_color': score_color(dim_score),
                'issues_count': len(brain_issues),
                'locked': False,
            })

    # 可见问题（免费用户只看 B1~B3）
    if vip:
        visible_issues = all_issues
    else:
        visible_issues = [i for i in all_issues if str(i.get('brain_id')) in ['1', '2', '3']]

    # 计算三层评级
    avail_brains = None if vip else ['1','2','3']
    tier_scores = calculate_tier_scores(all_issues, available_brain_ids=avail_brains, is_vip=vip)

    # 综合得分 + 三层综合评级
    score = scan['score']
    grade = scan['grade']
    # 确保 grade 是三层综合评级（兼容旧数据：旧数据只有单字母评级，重新算）
    if len(grade) <= 1:
        grade = calculate_overall_grade(tier_scores)

    created_at = scan['created_at']
    try:
        dt = datetime.strptime(created_at, '%Y-%m-%d %H:%M:%S')
        created_at_str = dt.strftime('%Y-%m-%d %H:%M')
    except (ValueError, TypeError):
        created_at_str = created_at

    return render_template(
        'report.html',
        scan_id=scan_id,
        report_title=scan['title'],
        score=score,
        grade=grade,
        file_count=scan['file_count'],
        total_issues=scan['issue_count'],
        created_at=created_at_str,
        dimensions=dimensions,
        tier_scores=tier_scores,
        tiers=TIERS,
        visible_issues=visible_issues,
        visible_issues_count=len(visible_issues),
        is_vip=vip,
    )


@app.route('/report/<scan_id>/download')
def download_report(scan_id):
    """下载报告（Markdown 格式）"""
    db = get_db()
    scan = db.execute('SELECT * FROM scans WHERE scan_id = ?', (scan_id,)).fetchone()

    if not scan:
        flash('检测报告不存在', 'error')
        return redirect(url_for('index'))

    results = json.loads(scan['results']) if scan['results'] else {'issues': []}
    all_issues = results.get('issues', [])
    vip = is_vip_user()

    if vip:
        visible_issues = all_issues
        visible_brains = BRAINS
    else:
        visible_issues = [i for i in all_issues if str(i.get('brain_id')) in ['1', '2', '3']]
        visible_brains = [b for b in BRAINS if b['id'] in ['1', '2', '3']]

    # 生成 Markdown
    md_lines = []
    md_lines.append(f'# 煋鉴 Xinpect 代码检测报告')
    md_lines.append('')
    md_lines.append(f'**检测名称：** {scan["title"]}')
    md_lines.append(f'**检测时间：** {scan["created_at"]}')
    md_lines.append(f'**文件数量：** {scan["file_count"]}')
    # 三层评级
    avail_brains_md = None if vip else ['1','2','3']
    tier_scores_md = calculate_tier_scores(all_issues, available_brain_ids=avail_brains_md, is_vip=vip)
    md_grade = calculate_overall_grade(tier_scores_md)

    md_lines.append(f'**综合评级：** {md_grade} 级')
    md_lines.append(f'**综合得分：** {scan["score"]} / 100')
    md_lines.append('')
    md_lines.append('**三层评级明细：**')
    md_lines.append('')
    md_lines.append('| 层级 | 名称 | 得分 | 评级 | 问题数 |')
    md_lines.append('|------|------|------|------|--------|')
    for tier in TIERS:
        ts = tier_scores_md[tier['key']]
        if ts.get('locked') or ts.get('score') is None:
            md_lines.append(f'| {tier["name"]} | {tier["subtitle"]} | 🔒 | 未解锁 | - |')
        else:
            md_lines.append(f'| {tier["name"]} | {tier["subtitle"]} | {ts["score"]} | {ts["grade"]} | {ts["issue_count"]} |')
    md_lines.append('')
    md_lines.append(f'**问题总数：** {len(visible_issues)}')
    if not vip:
        md_lines.append(f'> ⚡ 免费版仅展示 B1~B3 结果，[升级专业版](https://xinpect.xingwangzhineng.com) 解锁全部 8 维度')
    md_lines.append('')
    md_lines.append('---')
    md_lines.append('')

    # 各维度得分
    md_lines.append('## 各维度得分')
    md_lines.append('')
    md_lines.append('| 维度 | 名称 | 得分 | 问题数 |')
    md_lines.append('|------|------|------|--------|')
    for brain in BRAINS:
        if vip or brain['id'] in ['1', '2', '3']:
            brain_issues = [i for i in visible_issues if str(i.get('brain_id')) == brain['id']]
            dim_score = calculate_dimension_score(brain_issues)
            md_lines.append(f'| B{brain["id"]} | {brain["name"]} | {dim_score} | {len(brain_issues)} |')
        else:
            md_lines.append(f'| B{brain["id"]} | {brain["name"]} | 🔒 升级解锁 | - |')
    md_lines.append('')

    # 问题详情
    md_lines.append('## 问题详情')
    md_lines.append('')

    if not visible_issues:
        md_lines.append('🎉 **未检测到任何问题，代码质量优秀！**')
    else:
        # 按维度分组
        for brain in visible_brains:
            brain_issues = [i for i in visible_issues if str(i.get('brain_id')) == brain['id']]
            if not brain_issues:
                continue

            md_lines.append(f'### B{brain["id"]} {brain["name"]}')
            md_lines.append('')

            for idx, issue in enumerate(brain_issues, 1):
                sev_label = issue.get('severity_label', issue['severity'])
                md_lines.append(f'#### [{sev_label}] {idx}. {issue["title"]}')
                md_lines.append('')
                md_lines.append(f'- **规则ID：** {issue["rule_id"]}')
                md_lines.append(f'- **位置：** `{issue["file"]}:{issue["line"]}`')
                md_lines.append('')
                md_lines.append('**问题描述：**')
                md_lines.append('')
                md_lines.append(issue['description'])
                md_lines.append('')

                if issue.get('code_snippet'):
                    md_lines.append('**问题代码：**')
                    md_lines.append('')
                    md_lines.append('```')
                    md_lines.append(issue['code_snippet'])
                    md_lines.append('```')
                    md_lines.append('')

                if issue.get('suggestion'):
                    md_lines.append('**修复建议：**')
                    md_lines.append('')
                    md_lines.append(f'> {issue["suggestion"]}')
                    md_lines.append('')

            md_lines.append('---')
            md_lines.append('')

    md_lines.append('')
    md_lines.append('---')
    md_lines.append(f'*本报告由 [煋鉴 Xinpect](https://xinpect.xingwangzhineng.com) 自动生成*')

    md_content = '\n'.join(md_lines)

    # 生成中文文件名：煋鉴检测报告_项目名_年月日时分.md
    import re
    from urllib.parse import quote
    report_title = scan['title'] or '代码检测'
    title_safe = re.sub(r'[\\/:*?"<>|]', '', report_title).strip()[:30]
    time_str = scan['created_at'].replace('-', '').replace(':', '').replace(' ', '')[:12]
    filename_cn = f'煋鉴检测报告_{title_safe}_{time_str}.md'
    filename_encoded = quote(filename_cn)

    # 生成响应
    response = make_response(md_content)
    response.headers['Content-Type'] = 'text/markdown; charset=utf-8'
    response.headers['Content-Disposition'] = f"attachment; filename*=UTF-8''{filename_encoded}"
    return response


# ============================================================
# 认证路由
# ============================================================

@app.route('/login', methods=['GET', 'POST'])
def login():
    """登录"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        errors = {}

        if not email or not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email):
            errors['error_email'] = '请输入有效的邮箱地址'

        if not password:
            errors['error_password'] = '请输入密码'

        if errors:
            return render_template('login.html', email=email, **errors)

        db = get_db()
        user = db.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()

        if not user or not check_password_hash(user['password_hash'], password):
            errors['error_password'] = '邮箱或密码错误'
            return render_template('login.html', email=email, **errors)

        # 登录成功
        session['user_id'] = user['id']
        session['user_email'] = user['email']
        session['is_vip'] = bool(user['is_vip'])
        session['bonus_credits'] = user['bonus_credits'] or 0

        # 补写门房密码哈希（老用户没有）
        mf_pwd_hash = user['mf_password_hash'] if user['mf_password_hash'] else None
        if not mf_pwd_hash:
            mf_pwd_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()
            db.execute('UPDATE users SET mf_password_hash = ? WHERE id = ?', (mf_pwd_hash, user['id']))
            db.commit()

        # 同步登录门房，拿支付用的 token（失败不影响主流程）
        mf_token = _menfang_login_with_hash(email, mf_pwd_hash)
        if mf_token:
            session['mf_token'] = mf_token
        else:
            # 可能是老用户，门房没注册过，尝试补注册再登录
            _menfang_ensure_registered(email, mf_pwd_hash)
            mf_token = _menfang_login_with_hash(email, mf_pwd_hash)
            if mf_token:
                session['mf_token'] = mf_token

        flash('登录成功', 'success')

        next_url = request.args.get('next')
        if next_url and next_url.startswith('/'):
            return redirect(next_url)
        return redirect(url_for('dashboard_page'))

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """注册"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        errors = {}

        if not email or not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email):
            errors['error_email'] = '请输入有效的邮箱地址'

        if len(password) < 6:
            errors['error_password'] = '密码至少 6 位字符'

        if password != confirm_password:
            errors['error_confirm'] = '两次输入的密码不一致'

        if errors:
            return render_template('register.html', email=email, **errors)

        db = get_db()

        # 检查邮箱是否已注册
        existing = db.execute('SELECT id FROM users WHERE email = ?', (email,)).fetchone()
        if existing:
            errors['error_email'] = '该邮箱已被注册'
            return render_template('register.html', email=email, **errors)

        # 创建用户
        password_hash = generate_password_hash(password)
        mf_pwd_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()
        cursor = db.execute(
            'INSERT INTO users (email, password_hash, mf_password_hash) VALUES (?, ?, ?)',
            (email, password_hash, mf_pwd_hash)
        )
        db.commit()

        user_id = cursor.lastrowid

        # 同步注册到门房服务（用于支付，失败不影响主流程）
        _menfang_ensure_registered(email, mf_pwd_hash)

        # 自动登录
        session['user_id'] = user_id
        session['user_email'] = email
        session['is_vip'] = False

        flash('注册成功，欢迎使用煋鉴！', 'success')
        return redirect(url_for('dashboard_page'))

    return render_template('register.html')


@app.route('/logout')
def logout():
    """登出"""
    session.clear()
    flash('已退出登录', 'info')
    return redirect(url_for('index'))


@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    """忘记密码 - 发送重置验证码"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()

        if not email or not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email):
            flash('请输入有效的邮箱地址', 'error')
            return render_template('forgot_password.html', step=1, email=email)

        db = get_db()
        user = db.execute('SELECT id FROM users WHERE email = ?', (email,)).fetchone()

        if not user:
            # 不提示邮箱是否存在，防止枚举
            flash('如果该邮箱已注册，重置链接已发送到您的邮箱', 'info')
            return redirect(url_for('login'))

        # 生成6位验证码
        import random
        code = ''.join([str(random.randint(0, 9)) for _ in range(6)])
        expires_at = (datetime.now() + timedelta(minutes=15)).strftime('%Y-%m-%d %H:%M:%S')

        db.execute('INSERT INTO reset_codes (email, code, expires_at) VALUES (?, ?, ?)',
                   (email, code, expires_at))
        db.commit()

        # 保存到 session 用于下一步验证（开发阶段直接显示验证码）
        session['reset_email'] = email
        session['reset_code'] = code

        flash(f'验证码已生成（开发模式：{code}），15分钟内有效', 'info')
        return redirect(url_for('reset_password'))

    return render_template('forgot_password.html', step=1)


@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    """重置密码 - 验证验证码并设置新密码"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        code = request.form.get('code', '').strip()
        new_password = request.form.get('new_password', '')
        confirm_password = request.form.get('confirm_password', '')

        errors = {}

        if not email or not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email):
            errors['error_email'] = '请输入有效的邮箱地址'

        if len(code) != 6:
            errors['error_code'] = '请输入6位验证码'

        if len(new_password) < 6:
            errors['error_password'] = '密码至少6位字符'

        if new_password != confirm_password:
            errors['error_confirm'] = '两次输入的密码不一致'

        if errors:
            return render_template('forgot_password.html', step=2, email=email, code=code, **errors)

        db = get_db()
        reset_record = db.execute(
            'SELECT * FROM reset_codes WHERE email = ? AND code = ? AND used = 0 ORDER BY id DESC LIMIT 1',
            (email, code)
        ).fetchone()

        if not reset_record:
            errors['error_code'] = '验证码错误或已失效'
            return render_template('forgot_password.html', step=2, email=email, code=code, **errors)

        # 检查是否过期
        try:
            expires_at = datetime.strptime(reset_record['expires_at'], '%Y-%m-%d %H:%M:%S')
            if datetime.now() > expires_at:
                errors['error_code'] = '验证码已过期，请重新获取'
                return render_template('forgot_password.html', step=2, email=email, code=code, **errors)
        except Exception:
            pass

        # 更新密码
        password_hash = generate_password_hash(new_password)
        mf_pwd_hash = hashlib.sha256(new_password.encode('utf-8')).hexdigest()
        db.execute('UPDATE users SET password_hash = ?, mf_password_hash = ? WHERE email = ?',
                   (password_hash, mf_pwd_hash, email))
        db.execute('UPDATE reset_codes SET used = 1 WHERE id = ?', (reset_record['id'],))
        db.commit()

        # 同步更新门房密码
        try:
            if HAS_REQUESTS:
                http_requests.post(
                    f'{MENFANG_BASE_URL}/api/auth/register',
                    json={'email': email, 'password_hash': mf_pwd_hash},
                    timeout=5
                )
        except Exception:
            pass

        session.pop('reset_email', None)
        session.pop('reset_code', None)

        flash('密码重置成功，请用新密码登录', 'success')
        return redirect(url_for('login'))

    email = session.get('reset_email', '')
    return render_template('forgot_password.html', step=2, email=email)


@app.route('/dashboard/account')
@login_required
def account_page():
    """我的账户页面"""
    user = get_current_user()
    db = get_db()

    orders = db.execute(
        'SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 10',
        (user['id'],)
    ).fetchall()

    daily = get_daily_usage() if not is_vip_user() else 0
    daily_limit = DAILY_LIMIT_REGISTERED if session.get('user_id') else DAILY_LIMIT_FREE
    vip = is_vip_user()
    # v1.5: 只有会员才有积分相关数据
    credit_balance = get_user_credits(user['id']) if vip else 0
    credit_txs = get_credit_transactions(user['id'], limit=20) if vip else []
    return render_template('dashboard/account.html',
                           user=user,
                           orders=orders,
                           is_vip=vip,
                           daily_usage=daily,
                           daily_limit=daily_limit,
                           credit_balance=credit_balance,
                           credit_transactions=credit_txs,
                           page='account')


# ============================================================
# 会员中心
# ============================================================

@app.route('/dashboard')
@app.route('/dashboard/<page>')
@login_required
def dashboard_page(page='overview'):
    """会员中心各页面"""
    user = get_current_user()
    vip = is_vip_user()
    db = get_db()

    # 通用上下文
    # v1.5: 只有会员才有积分余额
    credit_balance = get_user_credits(user['id']) if vip and user else 0
    context = {
        'user_email': user['email'] if user else '',
        'is_vip': vip,
        'page': page,
        'bonus_credits': user['bonus_credits'] if user else 0,
        'credit_balance': credit_balance,  # v1.5: 积分余额（仅会员）
    }

    if page == 'overview':
        # 概览页：统计数据 + 最近检测
        today = datetime.now().strftime('%Y-%m-%d')
        usage_row = db.execute(
            'SELECT count FROM daily_usage WHERE date = ? AND user_id = ?',
            (today, user['id'])
        ).fetchone()
        today_scans = usage_row['count'] if usage_row else 0

        total_scans_row = db.execute(
            'SELECT COUNT(*) as cnt, COALESCE(SUM(issue_count), 0) as issues FROM scans WHERE user_id = ?',
            (user['id'],)
        ).fetchone()

        remaining = max(0, DAILY_LIMIT_REGISTERED - today_scans) if not vip else -1

        vip_expire = ''
        if vip and user['vip_expire_at']:
            try:
                vip_expire = user['vip_expire_at']
            except (KeyError, TypeError):
                vip_expire = '永久'

        context['stats'] = {
            'total_scans': total_scans_row['cnt'],
            'today_scans': today_scans,
            'remaining': remaining,
            'total_issues': total_scans_row['issues'],
        }
        context['vip_expire'] = vip_expire

        # 最近 5 条检测
        recent = db.execute(
            'SELECT scan_id, title, file_count, issue_count, score, grade, created_at, credits_spent '
            'FROM scans WHERE user_id = ? ORDER BY created_at DESC LIMIT 5',
            (user['id'],)
        ).fetchall()
        context['recent_scans'] = [dict(r) for r in recent]

        return render_template('dashboard/overview.html', **context)

    elif page == 'scans':
        # 我的检测
        scans = db.execute(
            'SELECT scan_id, title, file_count, issue_count, score, grade, created_at '
            'FROM scans WHERE user_id = ? ORDER BY created_at DESC',
            (user['id'],)
        ).fetchall()
        context['scans'] = [dict(s) for s in scans]
        return render_template('dashboard/scans.html', **context)

    elif page == 'orders':
        # 订单列表
        orders = db.execute(
            'SELECT order_id, plan_id, plan_name, amount, status, created_at '
            'FROM orders WHERE user_id = ? ORDER BY created_at DESC',
            (user['id'],)
        ).fetchall()
        context['orders'] = [dict(o) for o in orders]
        return render_template('dashboard/orders.html', **context)

    elif page == 'recharge':
        # 充值页
        return render_template('dashboard/recharge.html', **context)

    else:
        return redirect(url_for('dashboard_page', page='overview'))


# ============================================================
# JSON API
# ============================================================

@app.route('/api/pay/create', methods=['POST'])
@login_required
def api_pay_create():
    """创建支付订单（对接门房真实微信支付）"""
    data = request.get_json() or {}
    plan_id = data.get('plan_id')
    order_type = data.get('order_type', 'subscription')  # subscription / credit_pack / topup

    # 网站套餐 → 门房套餐映射
    subscription_plans = {
        'monthly':     {'name': '月卡',   'amount': 99,  'mf_plan': 'monthly'},
        'quarterly':   {'name': '季卡',   'amount': 249, 'mf_plan': 'quarterly'},
        'half_year':   {'name': '半年卡', 'amount': 449, 'mf_plan': 'half-year'},
        'yearly':      {'name': '年卡',   'amount': 799, 'mf_plan': 'yearly'},
    }

    # v1.5: 积分包商品
    credit_packs = CREDIT_PACKS

    topup_plans = {
        'topup_1':  {'name': '次卡·1次',  'amount': 2,  'mf_plan': 'addon-1',  'credits': 1},
        'topup_5':  {'name': '次卡·5次',  'amount': 9,  'mf_plan': 'addon-5',  'credits': 5},
        'topup_10': {'name': '次卡·10次', 'amount': 16, 'mf_plan': 'addon-10', 'credits': 10},
    }

    if order_type == 'credit_pack':
        # v1.5: 积分包（仅限会员购买，免费用户买了也用不了）
        if not is_vip_user():
            return jsonify({'success': False, 'error': '积分包仅限会员购买，请先开通会员'}), 403
        if plan_id not in credit_packs:
            return jsonify({'success': False, 'error': '无效的积分包'}), 400
        plan = credit_packs[plan_id]
    elif order_type == 'topup':
        # 次卡（保留兼容）仅限会员购买
        if not is_vip_user():
            return jsonify({'success': False, 'error': '次卡仅限会员购买，请先开通会员'}), 403
        if plan_id not in topup_plans:
            return jsonify({'success': False, 'error': '无效的次卡套餐'}), 400
        plan = topup_plans[plan_id]
    else:
        if plan_id not in subscription_plans:
            return jsonify({'success': False, 'error': '无效的套餐'}), 400
        plan = subscription_plans[plan_id]

    user = get_current_user()
    email = user['email']
    mf_token = session.get('mf_token', '')
    mf_pwd_hash = user['mf_password_hash'] or ''

    # 调门房创建真实支付订单（先试 token，失败就用密码哈希重登再试）
    result = _menfang_create_pay_order_with_token(email, mf_token, plan['mf_plan'], plan['amount'])

    # token 失效时用密码哈希重新登录再试
    if not result['success'] and mf_pwd_hash and ('登录已过期' in result.get('message', '') or '会话' in result.get('message', '')):
        new_token = _menfang_login_with_hash(email, mf_pwd_hash)
        if new_token:
            session['mf_token'] = new_token
            result = _menfang_create_pay_order_with_token(email, new_token, plan['mf_plan'], plan['amount'])

    # 还失败就用密码哈希直接调（最兜底的方式）
    if not result['success'] and mf_pwd_hash:
        result = _menfang_create_pay_order_with_hash(email, mf_pwd_hash, plan['mf_plan'], plan['amount'])

    if not result['success']:
        return jsonify({'success': False, 'error': result.get('message', '创建订单失败')}), 400

    mf_order_id = result['order_id']

    # 存本地订单（用门房的 order_id 作为关联）
    db = get_db()
    db.execute('''
        INSERT INTO orders (order_id, user_id, plan_id, plan_name, order_type, amount, status, mf_order_id)
        VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)
    ''', (mf_order_id, user['id'], plan_id, plan['name'], order_type, plan['amount'], mf_order_id))
    db.commit()

    return jsonify({
        'success': True,
        'order_id': mf_order_id,
        'amount': plan['amount'],
        'qr_url': result.get('qr_code_url', ''),
    })


@app.route('/api/pay/status/<order_id>')
@login_required
def api_pay_status(order_id):
    """查询支付状态（轮询门房真实订单状态）"""
    user = get_current_user()
    db = get_db()

    order = db.execute(
        'SELECT * FROM orders WHERE order_id = ? AND user_id = ?',
        (order_id, user['id'])
    ).fetchone()

    if not order:
        return jsonify({'status': 'not_found'}), 404

    # 如果本地已是 paid，直接返回
    if order['status'] == 'paid':
        return jsonify({'status': 'paid'})

    # 调门房查真实支付状态
    mf_status = _menfang_get_order_status(order_id)

    if not mf_status['found']:
        return jsonify({'status': order['status']})

    # 支付成功 → 开通权限 / 发放积分
    if mf_status['status'] == 'paid' and order['status'] != 'paid':
        if order['order_type'] == 'credit_pack':
            # v1.5: 积分包支付成功 → 发放积分
            pack = CREDIT_PACKS.get(order['plan_id'])
            credits = pack['credits'] if pack else 0

            db.execute('''
                UPDATE orders SET status = 'paid', paid_at = datetime('now', 'localtime')
                WHERE order_id = ?
            ''', (order_id,))
            db.commit()

            # 发放积分（写流水+更新余额）
            if credits > 0:
                grant_credits(user['id'], credits,
                              ref_type='credit_pack', ref_id=order_id,
                              remark=f'购买{pack["name"]}积分包')

            return jsonify({'status': 'paid'})

        elif order['order_type'] == 'topup':
            # 次卡：加 bonus_credits（旧逻辑保留兼容，同时也写入积分系统）
            credits_map = {
                'topup_1': 1,
                'topup_5': 5,
                'topup_10': 10,
            }
            credits = credits_map.get(order['plan_id'], 1)
            db.execute('''
                UPDATE orders SET status = 'paid', paid_at = datetime('now', 'localtime')
                WHERE order_id = ?
            ''', (order_id,))
            db.execute('''
                UPDATE users SET bonus_credits = COALESCE(bonus_credits, 0) + ? WHERE id = ?
            ''', (credits, user['id']))
            db.commit()
            session['bonus_credits'] = (session.get('bonus_credits') or 0) + credits

            # v1.5: 同时写入积分系统
            grant_credits(user['id'], credits,
                          ref_type='topup', ref_id=order_id,
                          remark=f'次卡充值{credits}次')

            return jsonify({'status': 'paid'})
        else:
            # 订阅卡：开 vip + 发放当月积分
            plan_info = SUBSCRIPTION_CREDITS.get(order['plan_id'], {})
            days = plan_info.get('days', 30)
            monthly_credits = plan_info.get('monthly_credits', 300)

            # 从门房的 paid_at 算起更准确，没有就用当前时间
            vip_expire = (datetime.now() + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')

            db.execute('''
                UPDATE orders SET status = 'paid', paid_at = datetime('now', 'localtime')
                WHERE order_id = ?
            ''', (order_id,))
            db.execute('''
                UPDATE users SET is_vip = 1, vip_expire_at = ? WHERE id = ?
            ''', (vip_expire, user['id']))
            db.commit()

            # v1.5: 立即发放当月积分
            grant_credits(user['id'], monthly_credits,
                          ref_type='subscription', ref_id=order_id,
                          remark=f'订阅{plan_info.get("name", "会员")}赠送{monthly_credits}积分')

            # 更新 session
            session['is_vip'] = True

            return jsonify({'status': 'paid'})

    return jsonify({'status': mf_status.get('status', order['status'])})


# ============================================================
# 错误处理
# ============================================================



# ============================
# 帮助中心 & 服务条款
# ============================

@app.route('/help')
def help_page():
    return render_template('help.html')


@app.route('/terms')
def terms_page():
    return render_template('terms.html')

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


@app.errorhandler(413)
def too_large(e):
    return jsonify({'error': '上传文件过大，总大小不能超过 20MB'}), 413


@app.errorhandler(500)
def server_error(e):
    app.logger.exception('Server error')
    return jsonify({'error': '服务器内部错误'}), 500


# ============================================================
# 启动
# ============================================================

if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 8621))
    debug = os.environ.get('FLASK_DEBUG', 'false').lower() == 'true'
    print('=' * 50)
    print('煋鉴 Xinpect 官网 v1.1')
    print('数据库:', DB_PATH)
    print('端口:', port)
    print('Debug:', debug)
    print('=' * 50)
    app.run(host='0.0.0.0', port=port, debug=debug)
