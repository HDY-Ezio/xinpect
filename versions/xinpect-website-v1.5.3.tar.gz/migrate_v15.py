#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
煋鉴官网 v1.5 积分制数据库迁移脚本
将 v1.4.1 数据库升级到 v1.5 积分制结构

使用方法：
    python3 migrate_v15.py         # 预览变更
    python3 migrate_v15.py --apply # 执行迁移
"""

import os
import sys
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'xinpect.db')


def table_exists(conn, table_name):
    """检查表是否存在"""
    row = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table_name,)
    ).fetchone()
    return row is not None


def column_exists(conn, table_name, column_name):
    """检查列是否存在"""
    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    return any(row[1] == column_name for row in rows)


def check_migrations(conn):
    """检查需要执行的迁移项，返回列表"""
    migrations = []

    # 1. user_credits 表
    if not table_exists(conn, 'user_credits'):
        migrations.append(('CREATE_TABLE', 'user_credits', '用户积分余额表'))

    # 2. credit_transactions 表
    if not table_exists(conn, 'credit_transactions'):
        migrations.append(('CREATE_TABLE', 'credit_transactions', '积分流水表'))

    # 3. scans 表新增字段
    if not column_exists(conn, 'scans', 'credits_spent'):
        migrations.append(('ADD_COLUMN', 'scans.credits_spent', '扫描消耗积分'))
    if not column_exists(conn, 'scans', 'total_lines'):
        migrations.append(('ADD_COLUMN', 'scans.total_lines', '总代码行数'))
    if not column_exists(conn, 'scans', 'scan_mode'):
        migrations.append(('ADD_COLUMN', 'scans.scan_mode', '扫描模式 basic/full'))

    # 4. 索引
    if table_exists(conn, 'user_credits'):
        idx = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_user_credits_user'"
        ).fetchone()
        if not idx:
            migrations.append(('CREATE_INDEX', 'idx_user_credits_user', 'user_credits用户索引'))
    if table_exists(conn, 'credit_transactions'):
        idx1 = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_credit_tx_user'"
        ).fetchone()
        if not idx1:
            migrations.append(('CREATE_INDEX', 'idx_credit_tx_user', '积分流水用户索引'))
        idx2 = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_credit_tx_created'"
        ).fetchone()
        if not idx2:
            migrations.append(('CREATE_INDEX', 'idx_credit_tx_created', '积分流水时间索引'))

    return migrations


def apply_migrations(conn):
    """执行迁移"""
    print('\n开始执行迁移...\n')

    # 1. 创建 user_credits 表
    if not table_exists(conn, 'user_credits'):
        conn.execute('''
            CREATE TABLE user_credits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER UNIQUE NOT NULL,
                balance INTEGER DEFAULT 0,
                total_earned INTEGER DEFAULT 0,
                total_spent INTEGER DEFAULT 0,
                updated_at TEXT DEFAULT (datetime('now', 'localtime')),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        print('  ✓ 创建 user_credits 表')

    # 2. 创建 credit_transactions 表
    if not table_exists(conn, 'credit_transactions'):
        conn.execute('''
            CREATE TABLE credit_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                balance_after INTEGER NOT NULL,
                ref_type TEXT,
                ref_id TEXT,
                remark TEXT,
                created_at TEXT DEFAULT (datetime('now', 'localtime')),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        print('  ✓ 创建 credit_transactions 表')

    # 3. scans 表新增字段
    if not column_exists(conn, 'scans', 'credits_spent'):
        conn.execute("ALTER TABLE scans ADD COLUMN credits_spent INTEGER DEFAULT 0")
        print('  ✓ 新增 scans.credits_spent')
    if not column_exists(conn, 'scans', 'total_lines'):
        conn.execute("ALTER TABLE scans ADD COLUMN total_lines INTEGER DEFAULT 0")
        print('  ✓ 新增 scans.total_lines')
    if not column_exists(conn, 'scans', 'scan_mode'):
        conn.execute("ALTER TABLE scans ADD COLUMN scan_mode TEXT DEFAULT 'basic'")
        print('  ✓ 新增 scans.scan_mode')

    # 4. 创建索引
    try:
        conn.execute('CREATE INDEX IF NOT EXISTS idx_user_credits_user ON user_credits(user_id)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_credit_tx_user ON credit_transactions(user_id)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_credit_tx_created ON credit_transactions(created_at)')
        print('  ✓ 创建/更新索引')
    except Exception as e:
        print(f'  ⚠ 索引创建: {e}')

    # 5. 为已有用户初始化积分账户（老用户注册赠送50积分）
    existing_users = conn.execute(
        "SELECT id FROM users WHERE id NOT IN (SELECT user_id FROM user_credits)"
    ).fetchall()
    if existing_users:
        for user in existing_users:
            conn.execute('''
                INSERT INTO user_credits (user_id, balance, total_earned, total_spent, updated_at)
                VALUES (?, 0, 0, 0, datetime('now', 'localtime'))
            ''', (user['id'],))
        print(f'  ✓ 为 {len(existing_users)} 个已有用户初始化积分账户')

    conn.commit()
    print('\n迁移完成！')


def main():
    apply = '--apply' in sys.argv

    if not os.path.exists(DB_PATH):
        print(f'数据库文件不存在: {DB_PATH}')
        print('（首次运行会自动创建，无需迁移）')
        return

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')

    print('=' * 60)
    print('煋鉴官网 v1.5 积分制数据库迁移')
    print('数据库:', DB_PATH)
    print('=' * 60)

    migrations = check_migrations(conn)

    if not migrations:
        print('\n✓ 数据库已是最新版本，无需迁移。')
        conn.close()
        return

    print(f'\n发现 {len(migrations)} 项待迁移：\n')
    for i, (op, target, desc) in enumerate(migrations, 1):
        print(f'  {i}. [{op}] {target} - {desc}')

    if not apply:
        print('\n预览模式，未执行任何变更。')
        print('如需执行迁移，请运行: python3 migrate_v15.py --apply')
    else:
        apply_migrations(conn)

    conn.close()


if __name__ == '__main__':
    main()
