#!/usr/bin/env python3
with open("templates/index.html", "r", encoding="utf-8") as f:
    html = f.read()

# 验证整体结构
sub_start = html.find('id="pricing-subscription"')
cred_start = html.find('id="pricing-credits"')
between = html[sub_start:cred_start]

opens = between.count("<div")
closes = between.count("</div>")
print(f"pricing-subscription 到 pricing-credits 之间:")
print(f"  <div 数: {opens}")
print(f"  </div 数: {closes}")
print(f"  净差（应=1）: {opens - closes}")

# recharge-plans 到积分包Tab
plans_start = html.find('class="recharge-plans" style="max-width:none')
year_end = html.find("<!-- 积分包 Tab -->")
plans_section = html[plans_start:year_end]
po = plans_section.count("<div")
pc = plans_section.count("</div>")
print(f"\nrecharge-plans 到 积分包Tab 之间:")
print(f"  <div 数: {po}")
print(f"  </div 数: {pc}")
print(f"  净差（应=1）: {po - pc}")

plan_count = plans_section.count('class="recharge-plan"')
print(f"\nrecharge-plan 卡片数: {plan_count} (应为5)")
