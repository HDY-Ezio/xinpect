#!/usr/bin/env python3
"""精准修复年卡闭合结构问题"""

with open("templates/index.html", "r", encoding="utf-8") as f:
    html = f.read()

# 找到年卡的结尾（unique pattern）
target = 'padding:3px 14px;border-radius:100px;font-size:12px;font-weight:600;">最划算</div>'
idx = html.find(target)
if idx == -1:
    print("ERROR: 没找到年卡'最划算'标记")
    exit(1)

# 看后面200字符
after = html[idx+len(target):idx+len(target)+200]
print("修复前：")
print(repr(after))

# 计算需要补几个 </div>
# 当前状态：年卡recharge-plan有最划算badge的div打开
# 应有结构：
#   </div> (最划算badge结束) ← 已有的
#   ... 年卡内容 ...
#   </div> (recharge-plan 年卡本身) ← 1
# </div> (recharge-plans grid) ← 2
# </div> (pricing-subscription tab-content) ← 3
# 然后才是 <!-- 积分包 Tab -->

# 检查从最划算到积分包Tab之间有多少个 </div>
credits_idx = html.find("<!-- 积分包 Tab -->")
between = html[idx:credits_idx]
close_count = between.count("</div>")
open_count = between.count("<div")
print(f"\n最划算到积分包之间:")
print(f"  <div 数量: {open_count}")
print(f"  </div> 数量: {close_count}")
print(f"  净闭合差: {open_count - close_count}")

# 精准替换：年卡的 recharge-plan 没有正确闭合
# 把 "最划算</div>\n        </div>\n\n        \n\n        <!-- 积分包" 
# 改为正确的嵌套闭合

old_pattern = '最划算</div>\n        </div>\n\n        \n\n        <!-- 积分包 Tab -->'
new_pattern = '最划算</div>\n            </div>\n            </div>\n        </div>\n\n        <!-- 积分包 Tab -->'

if old_pattern in html:
    html = html.replace(old_pattern, new_pattern)
    print("\n✅ 结构修复完成")
else:
    print("\n❌ 精确匹配失败，尝试模糊匹配")
    # 用正则
    import re
    pattern = r'最划算</div>\s*\n\s*</div>\s*\n\s*\n\s*<!-- 积分包 Tab -->'
    replacement = '最划算</div>\n            </div>\n            </div>\n        </div>\n\n        <!-- 积分包 Tab -->'
    html, n = re.subn(pattern, replacement, html)
    print(f"  正则替换了 {n} 处")

# 验证：再数一遍
between2 = html[html.find(target):html.find("<!-- 积分包 Tab -->")]
print(f"\n修复后验证:")
print(f"  <div 数量: {between2.count('<div')}")
print(f"  </div> 数量: {between2.count('</div>')}")

with open("templates/index.html", "w", encoding="utf-8") as f:
    f.write(html)

print("\n✅ 写入完成")
