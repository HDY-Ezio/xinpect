#!/usr/bin/env python3
"""重写首页定价区（对比区 + Tab切换 + 5列订阅 + 积分包）"""

with open("templates/index.html", "r", encoding="utf-8") as f:
    html = f.read()

# 找到定价区起止位置
start_marker = '<!-- 定价区 -->'
end_marker = '<!-- CTA 区 -->'

start_idx = html.find(start_marker)
end_idx = html.find(end_marker)

if start_idx == -1 or end_idx == -1:
    # 尝试其他标记
    print("尝试用section标记定位...")
    start_idx = html.find('<section class="section pricing-section">')
    end_idx = html.find('<!-- CTA 区 -->')
    if start_idx == -1:
        print(f"ERROR: 找不到起止标记 start={start_idx} end={end_idx}")
        exit(1)

print(f"定价区位置: {start_idx} ~ {end_idx} (共 {end_idx-start_idx} 字符)")

# 新的定价区内容
new_pricing = '''<!-- 定价区 -->
<section class="section pricing-section" id="pricing">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">透明定价</span>
            <h2 class="section-title">选择适合你的方案</h2>
            <p class="pricing-subtitle">免费体验基础检测，升级专业版解锁全部 8 维度AI能力 · 积分按行计费，用多少扣多少</p>
        </div>

        <!-- 性价比对比 -->
        <div style="margin-bottom:48px;background:linear-gradient(135deg,rgba(255,107,53,0.08),rgba(245,158,11,0.06));border-radius:24px;padding:48px 40px;position:relative;overflow:hidden;border:1px solid rgba(255,107,53,0.15);">
            <div style="position:absolute;top:-40px;right:-40px;width:200px;height:200px;background:radial-gradient(circle,rgba(255,107,53,0.12) 0%,transparent 70%);border-radius:50%;"></div>
            <div style="position:absolute;bottom:-60px;left:-30px;width:180px;height:180px;background:radial-gradient(circle,rgba(245,158,11,0.1) 0%,transparent 70%);border-radius:50%;"></div>

            <div style="text-align:center;margin-bottom:36px;position:relative;z-index:1;">
                <div style="display:inline-block;background:rgba(255,107,53,0.15);color:var(--accent-orange);padding:6px 18px;border-radius:100px;font-size:13px;font-weight:600;margin-bottom:16px;">💰 价格对比 · 透明定价</div>
                <h2 style="font-size:32px;font-weight:800;color:var(--text-primary);margin:0 0 12px;line-height:1.3;">
                    同等安全检测能力
                    <br>
                    <span style="background:linear-gradient(90deg,var(--accent-orange),#f59e0b);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">省 90% 以上的预算</span>
                </h2>
                <p style="color:var(--text-secondary);font-size:15px;margin:0;">不用几万块买工具，煋鉴让每个开发者都用得起专业级代码安全检测</p>
            </div>

            <div style="display:grid;grid-template-columns:1fr auto 1fr auto 1fr;gap:16px;align-items:stretch;max-width:1000px;margin:0 auto;position:relative;z-index:1;">
                <!-- 传统SAST -->
                <div style="background:#ffffff;border:1px solid #e5e7eb;border-radius:16px;padding:28px 20px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.04);">
                    <div style="font-size:12px;color:#6b7280;margin-bottom:12px;letter-spacing:1px;font-weight:500;">传统 SAST 工具</div>
                    <div style="font-size:13px;color:#9ca3af;text-decoration:line-through;margin-bottom:4px;">原价</div>
                    <div style="font-size:36px;font-weight:800;color:#1f2937;">¥5,000<span style="font-size:14px;font-weight:400;color:#9ca3af;">+</span></div>
                    <div style="font-size:13px;color:#6b7280;margin-top:4px;">/ 年 · 基础版</div>
                    <div style="margin-top:16px;padding-top:16px;border-top:1px dashed #e5e7eb;text-align:left;font-size:12px;color:#4b5563;line-height:2.2;">
                        <div>✗ 按代码量阶梯加价</div>
                        <div>✗ AI 功能单独付费</div>
                        <div>✗ 仅云端 SaaS 部署</div>
                        <div>✗ 误报率高</div>
                    </div>
                </div>

                <div style="display:flex;align-items:center;justify-content:center;">
                    <div style="width:40px;height:40px;background:#f3f4f6;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:#9ca3af;">VS</div>
                </div>

                <!-- 国际大厂 -->
                <div style="background:#ffffff;border:1px solid #e5e7eb;border-radius:16px;padding:28px 20px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.04);">
                    <div style="font-size:12px;color:#6b7280;margin-bottom:12px;letter-spacing:1px;font-weight:500;">国际大厂产品</div>
                    <div style="font-size:13px;color:#9ca3af;text-decoration:line-through;margin-bottom:4px;">原价</div>
                    <div style="font-size:36px;font-weight:800;color:#1f2937;">¥10,000<span style="font-size:14px;font-weight:400;color:#9ca3af;">+</span></div>
                    <div style="font-size:13px;color:#6b7280;margin-top:4px;">/ 年 · 企业版</div>
                    <div style="margin-top:16px;padding-top:16px;border-top:1px dashed #e5e7eb;text-align:left;font-size:12px;color:#4b5563;line-height:2.2;">
                        <div>✗ 按席位收费</div>
                        <div>✗ 高级功能加购</div>
                        <div>✗ 数据出境风险</div>
                        <div>✗ 中文支持弱</div>
                    </div>
                </div>

                <div style="display:flex;align-items:center;justify-content:center;">
                    <div style="font-size:28px;color:var(--accent-orange);font-weight:800;">→</div>
                </div>

                <!-- 煋鉴 -->
                <div style="background:linear-gradient(180deg,#fff7ed 0%,#ffffff 100%);border:2px solid var(--accent-orange);border-radius:16px;padding:28px 20px;text-align:center;position:relative;box-shadow:0 8px 32px rgba(255,107,53,0.2);">
                    <div style="position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:linear-gradient(90deg,var(--accent-orange),#f59e0b);color:#fff;padding:5px 18px;border-radius:100px;font-size:13px;font-weight:700;white-space:nowrap;">🔥 煋鉴 · 推荐</div>
                    <div style="font-size:12px;color:var(--accent-orange);margin-bottom:12px;letter-spacing:1px;font-weight:600;">煋鉴全功能版</div>
                    <div style="font-size:13px;color:var(--accent-orange);font-weight:600;margin-bottom:4px;">仅需</div>
                    <div style="font-size:48px;font-weight:900;color:var(--accent-orange);line-height:1;">¥799</div>
                    <div style="font-size:14px;color:#4b5563;margin-top:6px;font-weight:500;">/ 年 · 全量 AI 功能</div>
                    <div style="margin-top:16px;padding-top:16px;border-top:1px dashed rgba(255,107,53,0.4);text-align:left;font-size:12px;font-weight:500;line-height:2.2;">
                        <div style="color:#1f2937;">✓ 1积分/百行，透明计费</div>
                        <div style="color:#1f2937;">✓ AI 深度分析全包含</div>
                        <div style="color:#1f2937;">✓ 本地 + 云端双模式</div>
                        <div style="color:#1f2937;">✓ 行业领先低误报率</div>
                    </div>
                </div>
            </div>

            <div style="text-align:center;margin-top:28px;font-size:12px;color:var(--text-muted);position:relative;z-index:1;">
                * 对比数据基于行业公开信息整理，实际价格以各厂商官网为准
            </div>
        </div>

        <!-- Tab 切换 -->
        <div style="display:flex;justify-content:center;margin-bottom:32px;">
            <div style="display:inline-flex;background:var(--bg-secondary);border-radius:10px;padding:4px;">
                <button class="pricing-tab active" data-tab="subscription" onclick="switchPricingTab('subscription')" style="padding:10px 28px;border-radius:8px;border:none;background:var(--accent-orange);font-size:14px;font-weight:600;cursor:pointer;color:#fff;transition:all 0.2s;">
                    📅 订阅会员
                </button>
                <button class="pricing-tab" data-tab="credits" onclick="switchPricingTab('credits')" style="padding:10px 28px;border-radius:8px;border:none;background:transparent;font-size:14px;font-weight:600;cursor:pointer;color:var(--text-secondary);transition:all 0.2s;">
                    ⚡ 积分加量包
                </button>
            </div>
        </div>

        <!-- 订阅会员 Tab -->
        <div id="pricing-subscription" class="pricing-tab-content">
            <div class="recharge-plans" style="max-width:none;margin-bottom:24px;grid-template-columns:repeat(5,1fr);gap:12px;">
                <!-- 免费版 -->
                <div class="recharge-plan" style="cursor:default;">
                    <div class="recharge-plan-name">免费版</div>
                    <div class="recharge-plan-price" style="color:var(--text-primary);">
                        <span class="currency">¥</span>0
                    </div>
                    <div class="recharge-plan-period">永久免费</div>
                    <div class="recharge-plan-desc">每日 3 次基础扫描<br>适合轻度体验</div>
                    <ul style="text-align:left;font-size:13px;color:var(--text-secondary);margin-bottom:20px;display:flex;flex-direction:column;gap:6px;">
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> B1~B3 基础检测</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 30 文件/次上限</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 基础扫描报告</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 每天 3 次</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--text-muted);">—</span> AI 深度分析</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--text-muted);">—</span> 批量检测</li>
                    </ul>
                    <a href="{{ url_for('upload_page') }}" class="btn btn-secondary btn-block">开始使用</a>
                </div>

                <!-- 月卡 -->
                <div class="recharge-plan" onclick="window.location.href='{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}'">
                    <div class="recharge-plan-name">月卡</div>
                    <div class="recharge-plan-price">
                        <span class="currency">¥</span>99
                    </div>
                    <div class="recharge-plan-period">/ 月 · 300 积分</div>
                    <div class="recharge-plan-desc">约可扫 6 个中等项目<br>灵活便捷</div>
                    <ul style="text-align:left;font-size:13px;color:var(--text-secondary);margin-bottom:20px;display:flex;flex-direction:column;gap:6px;">
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> B1~B8 全维度</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 300 积分 / 月</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> AI 深度分析</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 报告下载</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 批量检测</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 邮件支持</li>
                    </ul>
                    <a href="{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}" class="btn btn-primary btn-block">开通</a>
                </div>

                <!-- 季卡 -->
                <div class="recharge-plan" onclick="window.location.href='{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}'">
                    <div class="recharge-plan-name">季卡</div>
                    <div class="recharge-plan-price">
                        <span class="currency">¥</span>249
                    </div>
                    <div class="recharge-plan-period">/ 季 · 350 积分/月（共 1,050）</div>
                    <div class="recharge-plan-desc">约可扫 21 个中等项目<br>性价比之选</div>
                    <ul style="text-align:left;font-size:13px;color:var(--text-secondary);margin-bottom:20px;display:flex;flex-direction:column;gap:6px;">
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> B1~B8 全维度</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 共 1,050 积分</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> AI 深度分析</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 报告下载</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 批量检测</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 优先技术支持</li>
                    </ul>
                    <a href="{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}" class="btn btn-primary btn-block">开通</a>
                </div>

                <!-- 半年卡 -->
                <div class="recharge-plan" onclick="window.location.href='{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}'">
                    <div class="recharge-plan-name">半年卡</div>
                    <div class="recharge-plan-price">
                        <span class="currency">¥</span>449
                    </div>
                    <div class="recharge-plan-period">/ 半年 · 400 积分/月（共 2,400）</div>
                    <div class="recharge-plan-desc">约可扫 48 个中等项目<br>团队首选</div>
                    <ul style="text-align:left;font-size:13px;color:var(--text-secondary);margin-bottom:20px;display:flex;flex-direction:column;gap:6px;">
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> B1~B8 全维度</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 共 2,400 积分</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> AI 深度分析</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 报告下载</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 批量检测</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 优先技术支持</li>
                    </ul>
                    <a href="{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}" class="btn btn-primary btn-block">开通</a>
                </div>

                <!-- 年卡 推荐 -->
                <div class="recharge-plan selected" onclick="window.location.href='{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}'">
                    <div style="position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:var(--gradient-orange);color:white;padding:3px 14px;border-radius:100px;font-size:12px;font-weight:600;">最划算</div>
                    <div class="recharge-plan-name">年卡</div>
                    <div class="recharge-plan-price">
                        <span class="currency">¥</span>799
                    </div>
                    <div class="recharge-plan-period">/ 年 · 500 积分/月（共 6,000）</div>
                    <div class="recharge-plan-desc">约可扫 120 个中等项目<br>企业级首选</div>
                    <ul style="text-align:left;font-size:13px;color:var(--text-secondary);margin-bottom:20px;display:flex;flex-direction:column;gap:6px;">
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> B1~B8 全维度</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 共 6,000 积分</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> AI 深度分析</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 报告下载</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> 批量检测</li>
                        <li style="display:flex;gap:8px;"><span style="color:var(--success);">✓</span> VIP 技术支持</li>
                    </ul>
                    <a href="{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}" class="btn btn-orange btn-block">立即开通</a>
                </div>
            </div>
        </div>

        <!-- 积分包 Tab -->
        <div id="pricing-credits" class="pricing-tab-content" style="display:none;">
            <div class="credit-packs-section">
                <div class="section-header" style="text-align:center;">
                    <span class="section-tag">积分补充</span>
                    <h2 class="section-title" style="font-size:28px;">积分加量包</h2>
                    <p class="pricing-subtitle" style="margin-bottom:32px;">会员专属 · 用量不够随时加 · 多买多优惠</p>
                </div>

                <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:16px;">
                    <div class="credit-pack-card">
                        <div class="credit-pack-name">体验包</div>
                        <div class="credit-pack-amount">100<span class="unit"> 积分</span></div>
                        <div class="credit-pack-price">¥49</div>
                        <div class="credit-pack-desc">约可扫 2 个<br>中等项目</div>
                        <a href="{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}" class="btn btn-secondary btn-block" style="font-size:13px;">购买</a>
                    </div>

                    <div class="credit-pack-card">
                        <div class="credit-pack-name">基础包</div>
                        <div class="credit-pack-amount">500<span class="unit"> 积分</span></div>
                        <div class="credit-pack-price">¥199 <span style="text-decoration:line-through;color:var(--text-muted);font-size:12px;">¥245</span></div>
                        <div class="credit-pack-desc">约可扫 10 个<br>中等项目</div>
                        <a href="{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}" class="btn btn-secondary btn-block" style="font-size:13px;">购买</a>
                    </div>

                    <div class="credit-pack-card">
                        <div class="credit-pack-name">标准包</div>
                        <div class="credit-pack-amount">2,000<span class="unit"> 积分</span></div>
                        <div class="credit-pack-price">¥599 <span style="text-decoration:line-through;color:var(--text-muted);font-size:12px;">¥980</span></div>
                        <div class="credit-pack-desc">约可扫 40 个<br>中等项目</div>
                        <a href="{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}" class="btn btn-secondary btn-block" style="font-size:13px;">购买</a>
                    </div>

                    <div class="credit-pack-card">
                        <div class="credit-pack-name">专业包</div>
                        <div class="credit-pack-amount">5,000<span class="unit"> 积分</span></div>
                        <div class="credit-pack-price">¥1,299 <span style="text-decoration:line-through;color:var(--text-muted);font-size:12px;">¥2,450</span></div>
                        <div class="credit-pack-desc">约可扫 100 个<br>中等项目</div>
                        <a href="{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}" class="btn btn-secondary btn-block" style="font-size:13px;">购买</a>
                    </div>

                    <div class="credit-pack-card" style="border-color:rgba(255,107,53,0.5);">
                        <div style="position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:rgba(255,107,53,0.15);color:var(--accent-orange);padding:2px 12px;border-radius:100px;font-size:11px;font-weight:600;">最划算 · 省¥4351</div>
                        <div class="credit-pack-name">企业包</div>
                        <div class="credit-pack-amount">15,000<span class="unit"> 积分</span></div>
                        <div class="credit-pack-price">¥2,999 <span style="text-decoration:line-through;color:var(--text-muted);font-size:12px;">¥7,350</span></div>
                        <div class="credit-pack-desc">约可扫 300 个<br>中等项目</div>
                        <a href="{{ url_for('dashboard_page', page='recharge') if session.get('user_id') else url_for('register') }}" class="btn btn-orange btn-block" style="font-size:13px;">立即购买</a>
                    </div>
                </div>

                <div class="credit-pack-note">
                    📌 积分包需配合会员使用，不单独解锁会员权限；积分包积分与月度积分同时存在，优先消耗月度积分
                </div>
            </div>
        </div>

        <div style="text-align:center;color:var(--text-muted);font-size:13px;margin-top:24px;">
            💡 所有档位权限一致，均为全维度 + AI 分析，仅积分量不同 · 积分当月有效，月底清零
        </div>
    </div>
</section>
'''

# 替换
new_html = html[:start_idx] + new_pricing + "\n" + html[end_idx:]

with open("templates/index.html", "w", encoding="utf-8") as f:
    f.write(new_html)

print(f"✅ 定价区重写完成，新文件 {len(new_html)} 字符")

# 验证结构
check_html = new_html
sub_start = check_html.find('id="pricing-subscription"')
cred_start = check_html.find('id="pricing-credits"')
cta_start = check_html.find('<!-- CTA 区 -->')

between1 = check_html[sub_start:cred_start]
print(f"\n订阅Tab内 div 净差: {between1.count('<div') - between1.count('</div>')} (应为1)")

between2 = check_html[cred_start:cta_start]
print(f"积分包Tab内 div 净差: {between2.count('<div') - between2.count('</div>')} (应为1)")

plan_count = between1.count('class="recharge-plan"')
pack_count = between2.count('class="credit-pack-card"')
print(f"\n订阅卡数量: {plan_count} (应为5)")
print(f"积分包数量: {pack_count} (应为5)")
