#!/usr/bin/env python3
"""一次性修复首页3个问题：
1. 对比区配色（前两栏半透明看不清 + 煋鉴白底太突兀）
2. 会员订阅区5列布局（年卡不再挤到第二排）
3. 积分包Tab结构（修复嵌套问题，内容独立显示）
"""
import re

HTML_PATH = "templates/index.html"
CSS_PATH = "static/css/style.css"

with open(HTML_PATH, "r", encoding="utf-8") as f:
    html = f.read()

# ========== 修复 1: 对比区前两栏配色 ==========
# 把 rgba(255,255,255,0.6) + backdrop-filter 换成纯白实底，文字改深色
old_card1 = 'background:rgba(255,255,255,0.6);backdrop-filter:blur(8px);border:1px solid var(--border-color);border-radius:16px;padding:28px 20px;text-align:center;'
new_card1 = 'background:#ffffff;border:1px solid #e5e7eb;border-radius:16px;padding:28px 20px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.04);'

# 替换前两栏（有两个相同的，replace_all）
html = html.replace(old_card1, new_card1)

# ========== 修复 2: 订阅区改成5列布局 ==========
# 订阅Tab的recharge-plans加上5列grid
old_sub_grid = '<div class="recharge-plans" style="max-width:none;margin-bottom:24px;">'
new_sub_grid = '<div class="recharge-plans" style="max-width:none;margin-bottom:24px;grid-template-columns:repeat(5,1fr);gap:12px;">'
html = html.replace(old_sub_grid, new_sub_grid)

# ========== 修复 3: 积分包Tab结构问题 ==========
# 根因：年卡的 div 没闭合，导致积分包内容被包在年卡里
# 找到年卡 section header 之后的结构，重新整理
# 先定位：从"年卡 推荐"开始到"积分包 Tab"之间的内容
# 直接找 pattern: 年卡 + selected + 最划算badge 后面缺少闭合

# 更简单的方法：找到 "<!-- 积分包 Tab -->" 前面的结构，确保正确闭合
# 先看年卡那一段的结尾
year_card_pattern = r'(<div class="recharge-plan" onclick=.*?年卡.*?最划算.*?</a>\s*\n\s*</div>\s*\n\s*</div>)'

# 实际上更直接：找到 "<!-- 积分包 Tab -->" 往前推，确保 subscription tab-content 正确闭合
# 检查 pricing-subscription 和 pricing-credits 的层级关系
# 正确结构应该是：
# <div id="pricing-subscription">...</div>
# <div id="pricing-credits">...</div>

# 检查 pricing-credits 前面有几个 </div>
credits_pos = html.find('<!-- 积分包 Tab -->')
before_credits = html[credits_pos-200:credits_pos]
print("=== 积分包Tab前200字符 ===")
print(before_credits[-150:])
print()

# 找到 subscription 的闭合结构
# 正确结构：年卡</div> + recharge-plans</div> + pricing-subscription</div> + 然后才是积分包Tab
# 现在的问题：多了个 </div> 或者少了个 </div>

# 用更稳妥的方法：重写整个定价区
# 先定位整个 section
pricing_start = html.find('<!-- 定价区 -->')
if pricing_start == -1:
    pricing_start = html.find('<section class="section pricing-section">')
print(f"定价区起始位置: {pricing_start}")

# 直接做精准修复：确保年卡div正确闭合
# 年卡的 recharge-plan 应该以 </div> 闭合（卡本身），然后 recharge-plans 闭合，然后 pricing-subscription 闭合

# 检查年卡附近的闭合标签
year_card_idx = html.find('最划算')
if year_card_idx > 0:
    context = html[year_card_idx:year_card_idx+800]
    print("=== 年卡附近结构 ===")
    # 数 </div>
    divs = re.findall(r'</div>', context)
    print(f"年卡后800字符内有 {len(divs)} 个 </div>")
    # 打印关键行
    lines = context.split('\n')
    for i, line in enumerate(lines[:20]):
        print(f"  {i}: {line[:80]}")

print("\n修复完成准备写入...")

with open(HTML_PATH, "w", encoding="utf-8") as f:
    f.write(html)

print("✅ 第1、2项修复已写入。第3项需要进一步分析结构。")
